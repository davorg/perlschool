#!/usr/bin/perl
  package MyWebServer;
  use strict; use warnings;
  use HTTP::Server::Simple::CGI;
  use base qw(HTTP::Server::Simple::CGI);
  use lib '../lib';
  use Login;
  
  my %dispatch = (
      '/' => \&Login::resp_login,
  );
 
  sub handle_request {
      my $self = shift;
      my $cgi  = shift;
    
      my $path = $cgi->path_info();
      my $handler = $dispatch{$path};
 
      if (ref($handler) eq "CODE") {
          print "HTTP/1.0 200 OK\r\n";
          $handler->($cgi);
         
      } else {
          print "HTTP/1.0 404 Not found\r\n";
          Login::prncgi $cgi, 'Not found',
              '<h1>Not found</h1>';
      }
  }
 
 # start the server on port 8888
  my $pid = MyWebServer->new(8888)->background();
  print "Use 'kill $pid' to stop server.\n";