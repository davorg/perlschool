#!perl
  use strict; use warnings;
  use Test::More;
  use Selenium::Chrome;
  use Test::BDD::Cucumber::StepFile;
  
  my $driver = Selenium::Chrome->new();
      
  When
    qr/\w* navigates to (.*)/,
    sub {
      $driver->get($1);
    };

  Then
    qr/he should see the userid and password boxes/,
    sub {
      like $driver->get_title, qr/Login Screen/,
        'Login screen found';
      is scalar (@{$driver->find_elements('userid', 'name')}),
        1, 'One userid box found';
      is scalar (@{$driver->find_elements('passwd', 'name')}),
        1, 'One password box found';
    };

  When
    qr/he enters (\w*) as (\w*)/,
    sub {
      $driver->find_element($2, 'name')->send_keys($1);
    };

  When
    qr/he clicks 'Submit'/,
    sub {
      $driver->find_element('button', 'name')->click;
    };

  Then
    qr/he gets a successful log in message/,
    sub {
      is $driver->get_title, 'Hello Adrian', 'Logged in title';
      like $driver->get_body, qr/You are logged in/, 
        'Logged in body';
    };

  Then
    qr/he gets an error message/,
    sub {
      is $driver->get_title, 'Invalid login', 'Failed login title';
      like $driver->get_body, qr/You don't exist/, 
        'Failed login body';
    };
