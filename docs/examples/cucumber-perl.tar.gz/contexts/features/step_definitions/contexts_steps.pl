#!perl
  use strict; use warnings;
  use Test::More;

  Given
    qr/^in S, (\w*) is set to (\w*)$/,
    sub {
      S->{$1} = $2;
    };

  Given
    qr/^in C, (\w*) is set to (\w*)$/,
    sub {
      C->{$1} = $2;
    };
    
  Then
    qr/^in S, (\w*) contains (\w*)$/,
    sub {
      is S->{$1}, $2, 'S\'s user defined property is correct';
    };

  Then
    qr/^in C, (\w*) contains (\w*)$/,
    sub {
      is C->{$1}, $2, 'C\'s user defined property is correct';
    };