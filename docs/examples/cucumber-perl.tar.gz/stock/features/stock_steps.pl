#!perl
  use strict; use warnings;
  use Test::BDD::Cucumber::StepFile;
  
  Given qr/stock is (\d+)$/,
    sub {
      
    };
    
  When qr/^(\d+) are (\w+)$/,
    sub {
      
    };
    
  Then qr/stock is (\d+)$/,
    sub {
      
    };