#!perl
  use strict; use warnings;
  use Test::More;
  use Test::BDD::Cucumber::StepFile;

  Quand qr/on entre (\d*\.?\d*) et (\d*\.?\d*)/, sub {
      S->{first}  = $1;
      S->{second} = $2;
  };

  Then qr/la syst\p{L}me rend (\d*\.?\d*)/, sub {
  # Then qr/la syst(\p{L})me rend (\d*\.?\d*)/, sub {
  # Then qr/la systÃ¨me rend (\d*\.?\d*)/, sub {
      is ($1, add(), 'Calculator works');
  };

  sub add {
      return S->{first} + S->{second};
  }