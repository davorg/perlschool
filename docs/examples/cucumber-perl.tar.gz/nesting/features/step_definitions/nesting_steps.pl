#!perl
  use strict; use warnings;
  use Test::More;

  Given qr/^input of (.*)$/,
    sub {
      S->{'data'} = $1;
    };

  Given qr/^raw input of (.*)$/,
    sub {
      S->{'data'} = $1;
    };

  Then qr/^reply should be (.*)$/,
    sub {
      is join(', ', reverse (split(' ', S->{'data'}))),
        $1, 'Data returned correctly';
      print "Sub called with $1\n";
    };

  Then qr/^(.*) should be returned$/,
    sub {
      C->dispatch('Then', "reply should be $1");
    };
