#!/usr/bin/perl
  use strict; use warnings;
  use Test::More;
  use Test::BDD::Cucumber::StepFile;
	 
  Given
    qr/some text/,
    sub {
      S->{'text'} = C->data;
    };

  When
    qr/the regex \[(.+)] is used/,
    sub {
      S->{'regex'} = $1;
    };

  Then
    qr/there \w+ (\d+) match/,
    sub {
      my $regex  = S->{'regex'};
      my $expect = $1;
      my $count = () = S->{'text'} =~ /\Q$regex\E/g;
      is $count, $expect,
        "Right number of matches found($count)";
    };
