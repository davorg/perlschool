#!/usr/bin/perl
  use strict; use warnings;
  use Test::More;
  use Test::BDD::Cucumber::StepFile;
	 
  package MockServer {
    sub get {
      my ($self, $url) = @_;
      if ('localhost:8888' eq $url) {
        return 'Hello stranger.';
      } elsif ('localhost:8888/TurnipseedDrongo' eq $url) {
        return 'You are logged in.';
      } else {
        return 'Go away. You don\'t exist.';
      }
    }
  };

  my $server;

  Before
    sub{
      $server = bless {}, 'MockServer';
      print "Server created\n";
    };

  Given
    qr/a connection to a server/,
    sub {
        ok defined $server;
        print "Server tested\n";
    };

  When
    qr/^\w+ navigates to (.*)/,
    sub {
      S->{'url'}  = $1;
    };
    
  Then
    qr/he should see the welcome screen/,
    sub {
      is $server->get(S->{'url'}),
        'Hello stranger.', 'Welcome screen found';
    };
    
  When
    qr/he enters (\w+) as (\w+)/,
    sub {
      S->{$2} = $1;
    };
    
  Then
    qr/he gets a successful log in message/,
    sub {
      is $server->get(S->{'url'} . '/' .
                      S->{'userid'} .
                      S->{'passwd'}
                     ),
        'You are logged in.', 'Login feature works';
    };
