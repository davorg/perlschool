package ShapeMaker;

use Class;
use Shape::Circle;
use Shape::Square;
use Shape::Rectangle;

sub BUILD {
    my ($self) = @_;

    $self->{circle}    = Shape::Circle->new;
    $self->{square}    = Shape::Square->new;
    $self->{rectangle} = Shape::Rectangle->new;
}

sub drawCircle    { shift->{circle}->draw    }
sub drawSquare    { shift->{square}->draw    }
sub drawRectangle { shift->{rectangle}->draw }

1;
