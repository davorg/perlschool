package ShapeMaker;

use Moo;

use Shape::Circle;
use Shape::Square;
use Shape::Rectangle;

has circle    => (is => 'ro', default => sub { Shape::Circle->new    });
has square    => (is => 'ro', default => sub { Shape::Square->new    });
has rectangle => (is => 'ro', default => sub { Shape::Rectangle->new });

sub drawCircle    { shift->circle->draw;    }
sub drawSquare    { shift->square->draw;    }
sub drawRectangle { shift->rectangle->draw; }

1;
