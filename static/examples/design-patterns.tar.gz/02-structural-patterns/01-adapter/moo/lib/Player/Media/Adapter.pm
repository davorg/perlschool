package Player::Media::Adapter;

use Moo;

has 'audio_type'   => (is => 'ro');
has 'music_player' => (is => 'rw');

with qw/Player::Media/;

use Player::AdvancedMedia::MP4;
use Player::AdvancedMedia::VLC;

sub BUILD {
    my ($self, $args) = @_;

    my $audio_type = $self->audio_type;
    if ($audio_type =~ /VLC/i) {
        $self->{music_player} = Player::AdvancedMedia::VLC->new;
    }
    elsif ($audio_type =~ /MP4/i) {
        $self->{music_player} = Player::AdvancedMedia::MP4->new;
    }
    else {
        die 'ERROR: Invalid audio type.';
    }
}

sub play {
    my ($self) = @_;

    my $audio_type = $self->audio_type;
    if ($audio_type =~ /VLC/i) {
        $self->music_player->playVLC;
    }
    elsif ($audio_type =~ /MP4/i) {
        $self->music_player->playMP4;
    }
}

1;
