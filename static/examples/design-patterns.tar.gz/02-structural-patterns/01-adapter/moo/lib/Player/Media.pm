package Player::Media;

use Moo::Role;
requires qw/play/;

1;
