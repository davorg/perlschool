package Player::AdvancedMedia;

use Moo::Role;
requires qw/playVLC playMP4/;

1;
