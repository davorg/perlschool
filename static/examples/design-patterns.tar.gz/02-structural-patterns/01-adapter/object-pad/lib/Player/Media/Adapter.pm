use Object::Pad;

class Player::Media::Adapter :does(Player::Media) {
    use Player::AdvancedMedia::MP4;
    use Player::AdvancedMedia::VLC;

    field $audio_type   :param :accessor;
    field $music_player :accessor;

    ADJUST {
        if ($audio_type =~ /VLC/i) {
            $self->music_player(Player::AdvancedMedia::VLC->new);
        }
        elsif ($audio_type =~ /MP4/i) {
            $self->music_player(Player::AdvancedMedia::MP4->new);
        }
        else {
            die 'ERROR: Invalid audio type.';
        }
    }

    method play {
        if ($audio_type =~ /VLC/i) {
            return $music_player->playVLC;
        }
        elsif ($audio_type =~ /MP4/i) {
            return $music_player->playMP4;
        }
    }
}

1;
