use Object::Pad;

class Player::AdvancedMedia::VLC :does(Player::AdvancedMedia) {
    method playVLC { 'Playing VLC.' }
    method playMP4 {                }
}

1;
