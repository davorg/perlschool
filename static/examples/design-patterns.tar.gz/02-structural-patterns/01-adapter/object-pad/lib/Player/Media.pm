use Object::Pad;

role Player::Media {
    method play;
}

1;
