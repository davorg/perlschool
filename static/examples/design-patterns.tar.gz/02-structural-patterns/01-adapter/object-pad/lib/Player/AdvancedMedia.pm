use Object::Pad;

role Player::AdvancedMedia {
    method playVLC;
    method playMP4;
}

1;
