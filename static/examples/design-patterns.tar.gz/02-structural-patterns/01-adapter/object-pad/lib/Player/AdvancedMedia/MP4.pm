use Object::Pad;

class Player::AdvancedMedia::MP4 :does(Player::AdvancedMedia) {
    method playVLC {                }
    method playMP4 { 'Playing MP4.' }
}

1;
