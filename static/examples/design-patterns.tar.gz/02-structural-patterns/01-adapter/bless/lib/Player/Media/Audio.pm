package Player::Media::Audio;

use Class;
with qw/Player::Media/;

use Player::Media::Adapter;

sub BUILD {
    my ($self, $args) = @_;

    if ($self->{audio_type} =~ /VLC|MP4/i) {
        $self->{audio} = Player::Media::Adapter->new(%$args);
    }
}

sub audio_type { shift->{audio_type} }
sub audio      { shift->{audio}      }

sub play {
    my ($self) = @_;

    my $audio_type = $self->audio_type;
    if ($audio_type =~ /VLC|MP4/i) {
        return $self->audio->play;
    }
    elsif ($audio_type =~ /MP3/i) {
        return 'Playing MP3.';
    }
}

1;
