package Player::Media;

use Role;
requires qw/play/;

1;
