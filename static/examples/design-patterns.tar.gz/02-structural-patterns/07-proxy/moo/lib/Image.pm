package Image;

use Moo::Role;
requires qw/display/;

1;
