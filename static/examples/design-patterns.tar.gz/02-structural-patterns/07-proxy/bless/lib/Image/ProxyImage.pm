package Image::ProxyImage;

use Image::RealImage;

use Class;
with qw/Image/;

sub BUILD {
    my ($self, $args) = @_;

    die "filename is required" unless exists $args->{filename};
}

sub filename { shift->{filename} }

sub display {
    my ($self) = @_;

    if (!defined $self->{image}) {
       $self->{image} = Image::RealImage->new(filename => $self->filename);
    }
    $self->{image}->display;
}

1;
