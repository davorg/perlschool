use Object::Pad;

class Image::ProxyImage :does(Image) {
    use Image::RealImage;

    field $filename :param :reader;
    field $image;

    method display {
        if (!defined $image) {
            $image = Image::RealImage->new(filename => $filename);
        }
        $image->display;
    }
}

1;
