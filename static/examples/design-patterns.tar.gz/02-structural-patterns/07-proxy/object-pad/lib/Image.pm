use Object::Pad;

role Image {
    method display;
}

1;
