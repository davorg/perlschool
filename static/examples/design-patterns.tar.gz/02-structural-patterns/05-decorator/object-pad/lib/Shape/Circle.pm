use Object::Pad;

class Shape::Circle :does(Shape) {
    method draw { 'A circle' }
}

1;
