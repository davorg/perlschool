use Object::Pad;

class ShapeDecorator :does(Shape) {
    field $shape :param :reader;

    BUILD       { die 'Invalid shape.' unless $shape->DOES('Shape') }
    method draw { $shape->draw                                      }
}

1;
