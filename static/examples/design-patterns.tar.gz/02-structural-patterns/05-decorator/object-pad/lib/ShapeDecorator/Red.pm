use Object::Pad;

class ShapeDecorator::Red :isa(ShapeDecorator) {
    method draw      { $self->SUPER::draw . $self->redBorder }
    method redBorder { ' with a red border'                  }
}

1;
