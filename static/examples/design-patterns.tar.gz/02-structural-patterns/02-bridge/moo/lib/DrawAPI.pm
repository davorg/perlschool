package DrawAPI;

use Moo::Role;
requires qw/drawCircle/;

1;
