package Shape;

use Role;
requires qw/draw/;

sub BUILD {
    die "Missing required key 'drawAPI'.\n" unless (exists shift->{drawAPI});
}

sub drawAPI { shift->{drawAPI} }

1;
