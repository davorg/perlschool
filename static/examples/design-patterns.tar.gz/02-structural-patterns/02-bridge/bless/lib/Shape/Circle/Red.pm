package Shape::Circle::Red;

use Class;
with qw/DrawAPI/;

sub drawCircle {
    my ($self, $radius, $x, $y) = @_;

    sprintf("drawCircle(color = red; radius = %d; x = %d; y = %d)",
        $radius, $x, $y);
}

1;
