use Object::Pad;

class Shape::Circle :does(Shape) {
    field $x      :accessor :param;
    field $y      :accessor :param;
    field $radius :accessor :param;

    method draw {
        $self->drawAPI->drawCircle($self->radius, $self->x, $self->y);
    }
}

1;
