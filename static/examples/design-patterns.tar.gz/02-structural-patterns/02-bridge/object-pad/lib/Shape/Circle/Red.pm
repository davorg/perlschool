use Object::Pad;

class Shape::Circle::Red :does(DrawAPI) {
    method drawCircle($radius, $x, $y) {
        sprintf("drawCircle(color = red; radius = %d; x = %d; y = %d)",
            $radius, $x, $y);
    }
}

1;
