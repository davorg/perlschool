use Object::Pad;

class Shape::Circle::Green :does(DrawAPI) {
    method drawCircle($radius, $x, $y) {
        sprintf("drawCircle(color = green; radius = %d; x = %d; y = %d)",
            $radius, $x, $y);
    }
}

1;
