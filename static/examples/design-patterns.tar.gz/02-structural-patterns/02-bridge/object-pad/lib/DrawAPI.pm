use Object::Pad;

role DrawAPI {
    method drawCircle;
}

1;
