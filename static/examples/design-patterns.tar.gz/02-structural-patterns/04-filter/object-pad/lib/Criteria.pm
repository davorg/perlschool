use Object::Pad;

role Criteria {
    method meetCriteria;
}

1;
