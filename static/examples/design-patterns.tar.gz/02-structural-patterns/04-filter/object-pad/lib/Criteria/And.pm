use Object::Pad;

class Criteria::And :does(Criteria) {
    field $criteria      :param :reader :writer;
    field $otherCriteria :param :reader :writer;

    method meetCriteria ($persons) {
        my $firstCriteria = $criteria->meetCriteria($persons);
        return $otherCriteria->meetCriteria([ map { $firstCriteria->{$_} } keys %$firstCriteria ]);
    }
}

1;
