use Object::Pad;

class Criteria::Single :does(Criteria) {
    method meetCriteria ($persons) {
        +{ map { $_->name => $_ } grep { uc($_->status) eq 'S' } @$persons };
    }
}

1;
