use Object::Pad;

class Criteria::Female :does(Criteria) {
    method meetCriteria ($persons) {
        +{ map { $_->name => $_ } grep { uc($_->gender) eq 'F' } @$persons };
    }
}

1;
