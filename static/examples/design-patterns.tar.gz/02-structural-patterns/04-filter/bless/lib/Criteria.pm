package Criteria;

use Role;
requires qw/meetCriteria/;

1;
