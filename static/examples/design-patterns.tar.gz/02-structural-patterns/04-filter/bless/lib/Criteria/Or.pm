package Criteria::Or;

use Class;
with qw/Criteria/;

sub criteria      { shift->{criteria}      }
sub otherCriteria { shift->{otherCriteria} }

sub meetCriteria {
    my ($self, $persons) = @_;

    my $firstCriteria = $self->criteria->meetCriteria($persons);
    my $otherCriteria = $self->otherCriteria->meetCriteria($persons);

    map {
        if (!exists $firstCriteria->{$_}) {
            $firstCriteria->{$_} = $otherCriteria->{$_};
        }
    } keys %$otherCriteria;

    $firstCriteria;
}

1;
