package Criteria::And;

use Class;
with qw/Criteria/;

sub criteria      { shift->{criteria}      }
sub otherCriteria { shift->{otherCriteria} }

sub meetCriteria {
    my ($self, $persons) = @_;

    my $firstCriteria = $self->criteria->meetCriteria($persons);
    $self->otherCriteria->meetCriteria([ map { $firstCriteria->{$_} } keys %$firstCriteria ]);
}

1;
