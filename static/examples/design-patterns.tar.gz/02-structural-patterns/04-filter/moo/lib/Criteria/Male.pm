package Criteria::Male;

use Moo;
with qw/Criteria/;

sub meetCriteria {
    my ($self, $persons) = @_;

    +{ map { $_->name => $_ } grep { uc($_->gender) eq 'M' } @$persons };
}

1;
