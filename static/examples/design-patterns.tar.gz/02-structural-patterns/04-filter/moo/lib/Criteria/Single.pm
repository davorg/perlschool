package Criteria::Single;

use Moo;
with qw/Criteria/;

sub meetCriteria {
    my ($self, $persons) = @_;

    +{ map { $_->name => $_ } grep { uc($_->status) eq 'S' } @$persons };
}

1;
