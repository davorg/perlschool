package Command;

use Moo::Role;
requires qw/execute unexecute/;

has light => (is => 'ro', required => 1);

1;
