package LightOffCommand;

use Class;
with qw/Command/;

sub execute   { shift->light->turn_off }
sub unexecute { shift->light->turn_on  }

1;
