package Command;

use Role;
requires qw/execute unexecute/;

sub BUILD { die "Missing required key 'light'.\n" unless (exists shift->{light}) }
sub light { shift->{light} }

1;
