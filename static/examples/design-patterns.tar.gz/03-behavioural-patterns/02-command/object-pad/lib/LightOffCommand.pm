use Object::Pad;

class LightOffCommand :does(Command) {
    method execute   { $self->light->turn_off }
    method unexecute { $self->light->turn_on  }
}

1;
