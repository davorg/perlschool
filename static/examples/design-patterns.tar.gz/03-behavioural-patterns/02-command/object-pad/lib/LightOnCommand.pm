use Object::Pad;

class LightOnCommand :does(Command) {
    method execute   { $self->light->turn_on  }
    method unexecute { $self->light->turn_off }
}

1;
