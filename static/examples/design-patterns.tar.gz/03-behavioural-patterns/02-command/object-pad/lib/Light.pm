use Object::Pad;

class Light {
    field $is_on :reader = 0;

    method turn_on  { $is_on = 1; 'ON'      }
    method turn_off { $is_on = 0; 'OFF'     }
    method status   { $is_on ? 'ON' : 'OFF' }
}

1;
