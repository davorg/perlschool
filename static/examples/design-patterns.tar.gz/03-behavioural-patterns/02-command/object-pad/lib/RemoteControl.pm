use Object::Pad;

class RemoteControl {
    field $command :accessor;
    field $history = [];

    method set_command($c) { $command = $c }

    method press_button {
        if ($self->command) {
            $self->command->execute;
            push @$history, $self->command;
        }
    }

    method undo {
        if (@$history) {
            my $last_command = pop @$history;
            $last_command->unexecute;
        }
    }
}

1;
