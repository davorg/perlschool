use Object::Pad;

class Observer::OctalObserver :does(Observer) {
    method update { sprintf("Octal string: %o.", $self->subject->state) }
}

1;
