package Observer;

use Object::Pad;

role Observer {
    field $subject :param :accessor;

    method update;
}

1;
