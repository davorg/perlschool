package Observer::HexaObserver;

use Moo;
with qw/Observer/;

sub update { sprintf("Hexa string: %x.", shift->subject->state) }

1;
