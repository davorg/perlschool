package Observer::BinaryObserver;

use Class;
with qw/Observer/;

sub BUILD {
    my ($self, $args) = @_;

    die "Missing key 'subject'." unless exists $args->{subject};
}

sub update { sprintf("Binary string: %b.", shift->subject->state) }

1;
