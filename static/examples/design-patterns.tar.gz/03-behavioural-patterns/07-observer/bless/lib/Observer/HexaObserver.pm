package Observer::HexaObserver;

use Class;
with qw/Observer/;

sub BUILD {
    my ($self, $args) = @_;

    die "Missing key 'subject'." unless exists $args->{subject};
}

sub update { sprintf("Hexa string: %x.", shift->subject->state) }

1;
