package Observer;

use Role;
requires qw/update/;

sub subject { shift->{subject} }

1;
