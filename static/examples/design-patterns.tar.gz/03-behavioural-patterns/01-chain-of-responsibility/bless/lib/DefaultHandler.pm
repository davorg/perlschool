package DefaultHandler;

use Class;
with qw/Handler/;

sub BUILD {
    my ($self) = @_;

    $self->{next} = undef;
}

sub handle {
    my ($self, $request) = @_;

    return "DefaultHandler handled everything else: $request";
}

1;
