package WordHandler;

use Class;
with qw/Handler/;

sub BUILD {
    my ($self) = @_;

    $self->{next} = undef;
}

sub handle {
    my ($self, $request) = @_;

    return "WordHandler processed request: $request" if ($request =~ /^[a-zA-Z]+$/);
    return $self->pass_to_next($request);
}

1;
