package NumberHandler;

use Class;
with qw/Handler/;

sub BUILD {
    my ($self) = @_;

    $self->{next} = undef;
}

sub handle {
    my ($self, $request) = @_;

    return "NumberHandler processed request: $request"
        if ($request =~ /^\d+$/);
    return $self->pass_to_next($request);
}

1;
