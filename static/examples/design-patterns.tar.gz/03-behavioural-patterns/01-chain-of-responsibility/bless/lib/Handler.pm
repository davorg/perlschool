package Handler;

use Role;
requires qw/handle/;

sub next {
    my ($self, $n) = @_;

    $self->{next} = $n if defined $n;
    $self->{next};
}

sub pass_to_next {
    my ($self, $request) = @_;

    return $self->next->handle($request) if $self->next;
    return "No handler could process request: $request";
}

1;
