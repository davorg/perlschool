use Object::Pad;

role Handler {
    field $next :accessor;

    method handle;

    method pass_to_next ($request) {
        return $next->handle($request) if ($next);
        return "No handler could process request: $request";
    }
}

1;
