use Object::Pad;

class WordHandler :does(Handler) {
    method handle($request) {
        return "WordHandler processed request: $request"   if ($request =~ /^[a-zA-Z]+$/);
        return $self->pass_to_next($request);
    }
}

1;
