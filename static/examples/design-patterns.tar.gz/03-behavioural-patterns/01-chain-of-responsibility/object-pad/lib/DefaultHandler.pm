use Object::Pad;

class DefaultHandler :does(Handler) {
    method handle($request) {
        return "DefaultHandler handled everything else: $request";
    }
}

1;
