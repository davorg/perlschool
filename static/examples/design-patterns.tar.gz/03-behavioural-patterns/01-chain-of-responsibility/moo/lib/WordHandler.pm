package WordHandler;

use Moo;
with qw/Handler/;

sub handle {
    my ($self, $request) = @_;

    return "WordHandler processed request: $request" if ($request =~ /^[a-zA-Z]+$/);
    return $self->pass_to_next($request);
}

1;
