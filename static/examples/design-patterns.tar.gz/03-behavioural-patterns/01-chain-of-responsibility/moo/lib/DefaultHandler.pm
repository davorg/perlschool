package DefaultHandler;

use Moo;
with qw/Handler/;

sub handle {
    my ($self, $request) = @_;

    return "DefaultHandler handled everything else: $request";
}

1;
