package TextFormatter;

use Class;

sub strategy {
    my ($self, $strategy) = @_;

    $self->{strategy} = $strategy if defined $strategy;
    return $self->{strategy};
}

sub publish {
    my ($self, $text) = @_;

    $self->{strategy}->format($text);
}

1;
