package UpperCaseFormatter;

use Class;
with qw/FormatterStrategy/;

sub format { uc $_[1] }

1;
