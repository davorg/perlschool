package UpperCaseFormatter;

use Moo;
with qw/FormatterStrategy/;

sub format { uc $_[1] }

1;
