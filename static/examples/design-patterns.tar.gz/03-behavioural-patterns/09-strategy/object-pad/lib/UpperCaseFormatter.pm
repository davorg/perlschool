use Object::Pad;

class UpperCaseFormatter :does(FormatterStrategy) {
    method format { uc $_[1] }
}

1;
