use Object::Pad;

role State {
    method doAction;
    method toString;
}

1;
