use Object::Pad;

class State::StartState :does(State) {
    method doAction($context) { $context->state($self) }
    method toString()         { 'Start State'          }
}

1;
