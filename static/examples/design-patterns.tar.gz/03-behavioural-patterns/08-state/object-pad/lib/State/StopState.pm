use Object::Pad;

class State::StopState :does(State) {
    method doAction($context) { $context->state($self) }
    method toString()         { 'Stop State'           }
}

1;
