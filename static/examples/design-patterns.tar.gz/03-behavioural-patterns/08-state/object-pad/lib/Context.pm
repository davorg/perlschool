use Object::Pad;

class Context {
    field $state :accessor;
}

1;
