package State::StopState;

use Class;
with qw/State/;

sub doAction {
    my ($self, $context) = @_;

    $context->state($self);
}

sub toString { 'Stop State' }

1;
