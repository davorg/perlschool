package State;

use Role;
requires qw/doAction toString/;

1;
