package Context;

use Class;

sub state {
    my ($self, $new_state) = @_;

    if (defined $new_state) {
        die "Invalid state" unless $new_state->isa('State');
        $self->{state} = $new_state;
    }
    return $self->{state};
}

1;
