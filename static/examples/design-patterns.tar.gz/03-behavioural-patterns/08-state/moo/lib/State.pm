package State;

use Moo::Role;
requires qw/doAction toString/;

1;
