package Add;

use Class;
with qw/Expression/;

sub BUILD {
    my ($self, $args) = @_;

    for (qw/left right/) {
        die "Missing required key: $_\n" unless (exists $args->{$_});
    }
}

sub interpret {
    my ($self) = @_;

    $self->{left}->interpret + $self->{right}->interpret
}

1;
