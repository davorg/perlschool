package Expression;

use Role;
requires qw/interpret/;

1;
