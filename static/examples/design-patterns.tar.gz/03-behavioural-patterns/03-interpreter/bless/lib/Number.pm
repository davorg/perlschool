package Number;

use Class;
with qw/Expression/;

sub interpret { shift->{value} }

1;
