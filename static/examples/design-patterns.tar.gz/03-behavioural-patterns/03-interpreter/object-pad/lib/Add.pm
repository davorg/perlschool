use Object::Pad;

class Add :does(Expression) {
    field $left  :param :accessor;
    field $right :param :accessor;

    method interpret { $self->left->interpret + $self->right->interpret }
}

1;
