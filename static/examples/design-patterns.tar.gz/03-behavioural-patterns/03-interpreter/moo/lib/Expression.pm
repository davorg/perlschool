package Expression;

use Moo::Role;
requires qw/interpret/;

1;
