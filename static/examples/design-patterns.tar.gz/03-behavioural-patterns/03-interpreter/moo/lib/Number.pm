package Number;

use Moo;
with qw/Expression/;

has value => (is => 'ro');

sub interpret { shift->value }

1;
