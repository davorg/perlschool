use v5.42;
use experimental qw/class/;

class Originator {
    use Memento;

    field $state :param :reader :writer(set_state);

    method save_state              { Memento->new(state => $state) }
    method restore_state($memento) { $state = $memento->state      }
}

1;
