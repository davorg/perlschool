use v5.42;
use experimental qw/class/;

class Caretaker {
    field $history = [];

    method add_memento($memento) { push @$history, $memento }
    method get_memento { pop @$history }
}

1;
