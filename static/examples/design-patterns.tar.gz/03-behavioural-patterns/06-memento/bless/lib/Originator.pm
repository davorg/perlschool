package Originator;

use Class;
use Memento;

sub state     { shift->{state}         }
sub set_state { $_[0]->{state} = $_[1] }

sub save_state {
    Memento->new(state => shift->state);
}

sub restore_state {
    my ($self, $memento) = @_;

    $self->set_state($memento->state);
}

1;
