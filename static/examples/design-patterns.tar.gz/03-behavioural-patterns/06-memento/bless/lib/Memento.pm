package Memento;

use Class;

sub state { shift->{state} }

1;
