package Originator;

use Memento;

use Moo;
has state => (is => 'rw');

sub set_state     { $_[0]->{state} = $_[1]              }
sub save_state    { Memento->new(state => $_[0]->state) }
sub restore_state { $_[0]->state($_[1]->state)          }

1;
