package Memento;

use Moo;

has state => (is => 'ro');

1;
