package ChatRoomMediator;

use Moo::Role;
requires qw/show_message/;

1;
