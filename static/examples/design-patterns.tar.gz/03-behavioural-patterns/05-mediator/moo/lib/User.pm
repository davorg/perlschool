package User;

use Moo;

has name              => (is => 'ro', required => 1);
has mediator          => (is => 'rw');
has received_messages => (is => 'rw', default  => sub {[]});
has verbose           => (is => 'rw', default  => 1);

sub send {
    my ($self, $message) = @_;

    $self->mediator->show_message($self, $message);
}

sub receive {
    my ($self, $from_user, $message) = @_;

    push @{$self->received_messages}, "$from_user->{name}: $message";
}

1;
