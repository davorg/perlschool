package User;

use Class;

sub BUILD {
    my ($self) = @_;

    $self->{mediator}         = undef;
    $self->{received_message} = [];
}

sub name              { shift->{name}     }
sub mediator          { shift->{mediator} }
sub set_mediator      { shift->{mediator} = $_[1]  }
sub received_messages { shift->{received_messages} }

sub send {
    my ($self, $message) = @_;

    die 'No mediator set' unless $self->mediator;
    $self->mediator->show_message($self, $message);
}

sub receive {
    my ($self, $from_user, $message) = @_;

    push @{$self->{received_messages}}, $from_user->name . ": $message";
}

1;
