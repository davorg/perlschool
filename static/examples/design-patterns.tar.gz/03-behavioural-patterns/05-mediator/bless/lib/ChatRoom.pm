package ChatRoom;

use Class;
with qw/ChatRoomMediator/;

sub register_user {
    my ($self, $user) = @_;

    push @{$self->{users}}, $user;
    $user->set_mediator($self);
}

sub show_message {
    my ($self, $from_user, $message) = @_;

    foreach my $user (@{$self->{users}}) {
        next if $user == $from_user;
        $user->receive($from_user, $message);
    }
}

1;
