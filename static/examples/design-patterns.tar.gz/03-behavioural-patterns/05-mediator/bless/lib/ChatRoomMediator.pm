package ChatRoomMediator;

use Role;
requires qw/show_message/;

1;
