use Object::Pad;

class ChatRoom :does(ChatRoomMediator) {
    field $users = [];

    method register_user($user) {
        push @$users, $user;
        $user->mediator($self);
    }

    method show_message($from_user, $message) {
        for my $user (@$users) {
            next if $user == $from_user;
            $user->receive($from_user, $message);
        }
    }
}

1;
