use Object::Pad;

class User {
    field $name              :param :reader;
    field $mediator          :accessor;
    field $received_messages :accessor = [];
    field $verbose           :param :accessor = 1;

    method send($message) { $self->mediator->show_message($self, $message) }

    method receive($from_user, $message) {
        push @$received_messages, $from_user->name . ": $message";
    }
}

1;
