package Visitor;

use Moo::Role;
requires qw/visit_circle visit_rectangle/;

1;
