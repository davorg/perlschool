package Shape;

use Moo::Role;
requires qw/accept/;

1;
