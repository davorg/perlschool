package Circle;

use Moo;
with qw/Shape/;

has radius => (is => 'ro', required => 1);

sub accept {
    my ($self, $visitor) = @_;

    $visitor->visit_circle($self);
}

1;
