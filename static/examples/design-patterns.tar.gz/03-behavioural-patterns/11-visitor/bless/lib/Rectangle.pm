package Rectangle;

use Class;
with qw/Shape/;

sub BUILD {
    my ($self, $args) = @_;

    foreach (qw/width height/) {
        die "Missing required key '$_'.\n" unless (exists $args->{$_});
    }
}

sub width  { shift->{width}  }
sub height { shift->{height} }

sub accept {
    my ($self, $visitor) = @_;

    $visitor->visit_rectangle($self);
}

1;
