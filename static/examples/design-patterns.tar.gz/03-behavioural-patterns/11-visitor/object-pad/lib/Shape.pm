use Object::Pad;

role Shape {
    method accept;
}

1;
