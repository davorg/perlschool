use Object::Pad;

role Visitor {
    method visit_circle;
    method visit_rectangle;
}

1;
