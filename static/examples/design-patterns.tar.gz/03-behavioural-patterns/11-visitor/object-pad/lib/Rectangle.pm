use Object::Pad;

class Rectangle :does(Shape) {
    field $width  :param :reader;
    field $height :param :reader;

    method accept($visitor) { $visitor->visit_rectangle($self) }
}

1;
