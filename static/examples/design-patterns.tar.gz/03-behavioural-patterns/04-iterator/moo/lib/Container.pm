package Container;

use Moo::Role;
requires qw/getIterator/;

1;
