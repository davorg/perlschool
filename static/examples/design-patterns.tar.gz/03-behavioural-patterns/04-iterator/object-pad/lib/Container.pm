use v5.42;
use Object::Pad;

role Container {
    method getIterator;
}

1;
