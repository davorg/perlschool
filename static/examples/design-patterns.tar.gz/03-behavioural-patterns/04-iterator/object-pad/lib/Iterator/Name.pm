use v5.42;
use Object::Pad;

class Iterator::Name :does(Iterator) {
    field $names :param  :reader;
    field $index :reader :writer = -1;

    method has_next { ($self->index < scalar(@{$self->names}) - 1) }

    method next {
        if ($self->has_next) {
            $self->set_index($self->index + 1);
            return $self->names->[$self->index];
        }
        return;
    }
}

1;
