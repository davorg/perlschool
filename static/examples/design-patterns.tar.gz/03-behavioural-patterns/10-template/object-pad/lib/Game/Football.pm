use Object::Pad;

class Game::Football :does(Game) {
    method initialise { print 'Football: initialise.'; }
    method startPlay  { print 'Football: start play.'; }
    method endPlay    { print 'Football: end play.';   }
}

1;
