package Game::Football;

use Class;
with qw/Game/;

sub initialise { print 'Football: initialise.'; }
sub startPlay  { print 'Football: start play.'; }
sub endPlay    { print 'Football: end play.';   }

1;
