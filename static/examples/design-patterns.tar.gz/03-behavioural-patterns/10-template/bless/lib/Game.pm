package Game;

use Role;

requires qw/initialise startPlay endPlay/;

sub play {
    my ($self) = @_;

    $self->initialise;
    $self->startPlay;
    $self->endPlay;
}

1;
