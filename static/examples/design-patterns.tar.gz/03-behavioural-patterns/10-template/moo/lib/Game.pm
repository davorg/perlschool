package Game;

use Moo::Role;

requires qw/initialise startPlay endPlay/;

sub play($self) {
    $self->initialise;
    $self->startPlay;
    $self->endPlay;
}

1;
