package MealBuilder;

use Meal;
use Item::ColdDrink::Coke;
use Item::ColdDrink::Pepsi;
use Item::Burger::VegBurger;
use Item::Burger::ChickenBurger;

use Class;

sub prepareVegMeal    {
    my $meal = Meal->new;
    $meal->addItem(Item::Burger::VegBurger->new);
    $meal->addItem(Item::ColdDrink::Coke->new);
    return $meal;
}

sub prepareNonVegMeal {
    my $meal = Meal->new;
    $meal->addItem(Item::Burger::ChickenBurger->new);
    $meal->addItem(Item::ColdDrink::Pepsi->new);
    return $meal;
}

1;
