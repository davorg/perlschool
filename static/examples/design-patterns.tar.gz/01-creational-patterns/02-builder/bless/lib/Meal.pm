package Meal;

use Class;

sub BUILD { shift->{items} = []; }
sub items { shift->{items}       }
sub addItem {
    my ($self, $item) = @_;
    push @{$self->items}, $item
}

sub getCost {
    my ($self) = @_;
    my $cost = 0;
    $cost += $_->price for @{$self->items};
    return $cost;
}

sub getItems {
    [
        map [ $_->name, $_->packing->pack, $_->price ],
        @{shift->items}
    ];
}

1;
