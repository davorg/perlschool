package Item::Burger;

use Packing::Wrapper;
use Role;
with qw/Item/;
requires qw/name price/;

sub packing { Packing::Wrapper->new }

1;
