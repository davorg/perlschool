package Item::ColdDrink::Pepsi;

use Class;
with qw/Item::ColdDrink/;

sub name  { 'Pepsi' }
sub price { 14      }

1;
