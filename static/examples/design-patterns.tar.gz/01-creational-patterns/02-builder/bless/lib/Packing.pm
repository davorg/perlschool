package Packing;

use Role;
requires qw/pack/;

1;
