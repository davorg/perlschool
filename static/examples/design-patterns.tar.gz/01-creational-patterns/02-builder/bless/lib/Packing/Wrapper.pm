package Packing::Wrapper;

use Class;
with qw/Packing/;

sub pack { 'Wrapper' }

1;
