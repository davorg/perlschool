package Packing::Bottle;

use Class;
with qw/Packing/;

sub pack { 'Bottle' }

1;
