use Object::Pad;

role Item {
    method name    :required;
    method price   :required;
    method packing :required;
}

1;
