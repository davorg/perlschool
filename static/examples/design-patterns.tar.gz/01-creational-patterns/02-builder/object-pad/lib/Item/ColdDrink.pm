use Packing::Bottle;

use Object::Pad;

role Item::ColdDrink :does(Item) {
    method name;
    method price;
    method packing { Packing::Bottle->new }
}

1;
