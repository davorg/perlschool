use Object::Pad;

class Item::ColdDrink::Coke :does(Item::ColdDrink) {
    method name  { 'Coke' }
    method price { 12     }
}

1;
