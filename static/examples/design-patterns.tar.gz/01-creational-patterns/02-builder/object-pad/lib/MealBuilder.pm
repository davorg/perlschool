use Meal;
use Item::ColdDrink::Coke;
use Item::ColdDrink::Pepsi;
use Item::Burger::VegBurger;
use Item::Burger::ChickenBurger;

use Object::Pad;

class MealBuilder {
    method prepareVegMeal {
        my $meal = Meal->new;
        $meal->addItem(Item::Burger::VegBurger->new);
        $meal->addItem(Item::ColdDrink::Coke->new);
        return $meal;
    }

    method prepareNonVegMeal {
        my $meal = Meal->new;
        $meal->addItem(Item::Burger::ChickenBurger->new);
        $meal->addItem(Item::ColdDrink::Pepsi->new);
        return $meal;
    }
}

1;
