package MealBuilder;

use Moo;
use Meal;
use Item::ColdDrink::Coke;
use Item::ColdDrink::Pepsi;
use Item::Burger::VegBurger;
use Item::Burger::ChickenBurger;

sub prepareVegMeal {
    my ($self) = @_;

    my $meal = Meal->new;
    $meal->addItem(Item::Burger::VegBurger->new);
    $meal->addItem(Item::ColdDrink::Coke->new);
    return $meal;
}

sub prepareNonVegMeal {
    my ($self) = @_;

    my $meal = Meal->new;
    $meal->addItem(Item::Burger::ChickenBurger->new);
    $meal->addItem(Item::ColdDrink::Pepsi->new);
    return $meal;
}

1;
