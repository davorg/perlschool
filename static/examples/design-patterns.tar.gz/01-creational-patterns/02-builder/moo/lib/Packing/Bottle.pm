package Packing::Bottle;

use Moo;
with qw/Packing/;

sub pack { 'Bottle' }

1;
