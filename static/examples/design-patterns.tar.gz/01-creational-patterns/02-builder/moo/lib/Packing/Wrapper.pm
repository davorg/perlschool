package Packing::Wrapper;

use Moo;
with qw/Packing/;

sub pack { 'Wrapper' }

1;
