package Item::Burger::ChickenBurger;

use Moo;
with qw/Item::Burger/;

sub name  { 'Chicken Burger' }
sub price { 20               }

1;
