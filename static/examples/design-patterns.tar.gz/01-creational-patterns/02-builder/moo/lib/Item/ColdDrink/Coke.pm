package Item::ColdDrink::Coke;

use Moo;
with qw/Item::ColdDrink/;

sub name  { 'Coke' }
sub price { 12     }

1;
