package Item::ColdDrink::Pepsi;

use Moo;
with qw/Item::ColdDrink/;

sub name  { 'Pepsi' }
sub price { 14      }

1;
