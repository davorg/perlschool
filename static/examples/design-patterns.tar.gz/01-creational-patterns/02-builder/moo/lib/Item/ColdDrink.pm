package Item::ColdDrink;

use Packing::Bottle;

use Moo::Role;
with qw/Item/;
requires qw/name price/;

sub packing { Packing::Bottle->new }

1;
