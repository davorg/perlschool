package Item::Burger::VegBurger;

use Moo;
with qw/Item::Burger/;

sub name  { 'Veg Burger' }
sub price { 10           }

1;
