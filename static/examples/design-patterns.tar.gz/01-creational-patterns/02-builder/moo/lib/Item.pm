package Item;

use Moo::Role;
requires qw/name price packing/;

1;
