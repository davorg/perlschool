package Meal;

use Moo;

has 'items' => (is => 'rw', default => sub {[]});

sub addItem {
    my ($self, $item) = @_;
    push @{$self->items}, $item
}

sub getCost {
    my $cost = 0;
    $cost += $_->price for @{shift->items};
    return $cost;
}

sub getItems {
    [
        map [ $_->name, $_->packing->pack, $_->price ],
        @{shift->items}
    ];
}

1;
