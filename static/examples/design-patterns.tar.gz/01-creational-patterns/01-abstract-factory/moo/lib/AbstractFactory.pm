package AbstractFactory;

use Moo::Role;
requires qw/getShape/;

1;
