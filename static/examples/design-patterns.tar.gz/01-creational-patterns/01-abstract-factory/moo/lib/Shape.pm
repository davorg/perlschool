package Shape;

use Moo::Role;
requires qw/draw/;

1;
