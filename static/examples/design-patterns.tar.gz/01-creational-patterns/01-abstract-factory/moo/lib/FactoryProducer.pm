package FactoryProducer;

use Moo;
use AbstractFactory::ShapeFactory;
use AbstractFactory::RoundedShapeFactory;

sub getFactory {
    my ($self, $rounded) = @_;

    return $rounded
        ? AbstractFactory::RoundedShapeFactory->new
        : AbstractFactory::ShapeFactory->new;
}

1;
