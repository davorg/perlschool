use Object::Pad;

role Shape {
    method draw;
}

1;
