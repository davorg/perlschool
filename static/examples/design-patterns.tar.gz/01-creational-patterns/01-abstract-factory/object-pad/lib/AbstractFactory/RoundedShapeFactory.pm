use Shape::RoundedSquare;
use Shape::RoundedRectangle;

use Object::Pad;

class AbstractFactory::RoundedShapeFactory :does(AbstractFactory) {
    method getShape($shapeType) {
        if (uc($shapeType) eq 'RECTANGLE') {
            return Shape::RoundedRectangle->new;
        }
        elsif (uc($shapeType) eq 'SQUARE') {
            return Shape::RoundedSquare->new;
        }
        return;
    }
}

1;
