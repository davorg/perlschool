use Object::Pad;

role AbstractFactory {
    method getShape;
}

1;
