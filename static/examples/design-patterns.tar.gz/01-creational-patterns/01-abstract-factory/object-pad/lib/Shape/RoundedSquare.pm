use Object::Pad;

class Shape::RoundedSquare :does(Shape) {
    method draw { 'Inside Shape::RoundedSquare::draw()' }
}

1;
