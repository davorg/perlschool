use Object::Pad;

class Shape::RoundedRectangle :does(Shape) {
    method draw { 'Inside Shape::RoundedRectangle::draw()' }
}

1;
