package Shape::Rectangle;

use Class;
with qw/Shape/;

sub draw { 'Inside Shape::Rectangle::draw()' }

1;
