package Shape::Square;

use Class;
with qw/Shape/;

sub draw { 'Inside Shape::Square::draw()' }

1;
