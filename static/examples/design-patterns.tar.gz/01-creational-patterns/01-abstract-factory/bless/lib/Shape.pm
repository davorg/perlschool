package Shape;

use Role;
requires qw/draw/;

1;
