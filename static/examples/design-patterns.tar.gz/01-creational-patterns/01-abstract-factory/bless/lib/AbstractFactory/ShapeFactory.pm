package AbstractFactory::ShapeFactory;

use Shape::Square;
use Shape::Rectangle;

use Class;
with qw/AbstractFactory/;

sub getShape {
    my ($self, $shapeType) = @_;

    if (uc($shapeType) eq 'RECTANGLE') {
        return Shape::Rectangle->new;
    }
    elsif (uc($shapeType) eq 'SQUARE') {
        return Shape::Square->new;
    }
    return;
}

1;
