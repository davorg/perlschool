use v5.42;
use experimental qw/class/;

class Shape::Rectangle :isa(Shape)    {
    field $type :reader :param = 'Rectangle';

    method draw { 'Inside Shape::Rectangle::draw()' }
}

1;
