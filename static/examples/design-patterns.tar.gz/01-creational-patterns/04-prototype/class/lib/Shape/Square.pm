use v5.42;
use experimental qw/class/;

class Shape::Square :isa(Shape)    {
    field $type :reader :param = 'Square';

    method draw { 'Inside Shape::Square::draw()' }
}

1;
