package Shape::Square;

use Moo;
extends qw/Shape/;

has 'type'   => (
    is       => 'ro',
    required => 1,
    default  => sub { 'Square' },
);

sub draw { 'Inside Shape::Square::draw()' }

1;
