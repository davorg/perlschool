package Shape::Rectangle;

use Moo;
extends qw/Shape/;

has 'type'   => (
    is       => 'ro',
    required => 1,
    default  => sub { 'Rectangle' },
);

sub draw { 'Inside Shape::Rectangle::draw()' }

1;
