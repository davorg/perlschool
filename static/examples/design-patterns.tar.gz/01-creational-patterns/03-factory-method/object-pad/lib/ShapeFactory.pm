use Object::Pad;

class ShapeFactory {
    use Shape::Circle;
    use Shape::Square;
    use Shape::Rectangle;

    my %dispatch = (
        CIRCLE    => 'Shape::Circle',
        SQUARE    => 'Shape::Square',
        RECTANGLE => 'Shape::Rectangle'
    );

    method getShape($shapeType) {
        my $class = $dispatch{ uc $shapeType };
        return unless $class;
        return $class->new;
    }
}

1;
