package Shape::Circle;

use Moo;
with qw/Shape/;

sub draw { 'Inside Shape::Circle::draw()' }

1;
