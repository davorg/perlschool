package ShapeFactory;

use Shape::Circle;
use Shape::Square;
use Shape::Rectangle;

use Class;

my %dispatch = (
    CIRCLE    => 'Shape::Circle',
    SQUARE    => 'Shape::Square',
    RECTANGLE => 'Shape::Rectangle'
);

sub getShape {
    my ($self, $shapeType) = @_;

    my $class = $dispatch{ uc $shapeType };
    return unless $class;
    return $class->new;
}

1;
