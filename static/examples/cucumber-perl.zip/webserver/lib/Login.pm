  package Login;
  use strict; use warnings;

my $loginpage = <<END_OF_LOGIN;
<form>
    <h1>Login form</h1>
    User ID  <input name="userid" size="50">                </input><br/>
    Password <input name="passwd" size="50" type="password"></input><br/>
             <input name="button" type="submit">            </input><br/>
</form>
END_OF_LOGIN

  my $acceptpage = '<h1>You are logged in</h1>';
  my $rejectpage = '<h1>You don\'t exist. Go away.</h1>';
  my %users = (
      'Turnipseed' => {
          'passwd' => 'Drongo',
          'name'   => 'Adrian',
      }
  );

  sub prncgi {
    my ($cgi, $start, $page) = @_;
      print $cgi->header,
          $cgi->start_html($start),
          $page,
          $cgi->end_html;
  }
 
  sub resp_login {
      my $cgi  = shift;
      my $userid = $cgi->param('userid');
      my $passwd = $cgi->param('passwd');
      if (defined $userid or defined $passwd) {
          my $lookup = $users{$userid}{'passwd'} || '';
          if ($passwd eq $lookup and '' ne $lookup) {
              prncgi $cgi, "Hello $users{$userid}{'name'}", $acceptpage;
          } else {
              prncgi $cgi, 'Invalid login', $rejectpage;
          }
      } else {
          prncgi $cgi, 'Login Screen', $loginpage;
      }
  }
    
  1;