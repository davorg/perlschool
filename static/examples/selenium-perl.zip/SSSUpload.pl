    use strict; use warnings;
    use Selenium::Remote::Driver;

    open my $fh, '>', 'upfile.txt' or die
        "Can't open upfile.txt for output: $!";
    print $fh "File contents\n";
    close $fh;
    my $driver = Selenium::Remote::Driver->new(
        remote_server_addr => '127.0.0.1',
        port               => '4444',
        browser_name       => 'chrome'
    );
    my $remote_file_name = 
        $driver->upload_file('upfile.txt');
    print "$remote_file_name\n";
    my $wait = <STDIN>;
    unlink 'upfile.txt';
    $driver->quit();