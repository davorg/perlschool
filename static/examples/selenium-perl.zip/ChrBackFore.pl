    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $link   = 'Recently Active Threads';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    $driver->find_element_by_link_text($link)->click;
    is $driver->get_title(),
        'Recently Active Threads',
        'Title as expected';
    $driver->go_back;
    is $driver->get_title(),
        'PerlMonks - The Monastery Gates',
        'Title as expected after back';
    $driver->go_forward;
    is $driver->get_title(),
        'Recently Active Threads',
        'Title as expected after forward';
    $driver->refresh;
    is $driver->get_title(),
        'Recently Active Threads',
        'Title as expected after refresh';
    $driver->quit();
    done_testing;