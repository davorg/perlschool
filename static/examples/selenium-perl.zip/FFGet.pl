    use strict; use warnings;
    use feature 'say';
    use Selenium::Firefox;

    my $driver = Selenium::Firefox->new();
    $driver->get('http://www.perlmonks.org');
    say $driver->get_title();
    $driver->quit();