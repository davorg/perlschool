    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->find_element(
        'Voting_Booth', 'id');
    my $child = $driver->find_child_element
        ($elt, "//input[\@value='Vote']");
    is $child->get_tag_name(),
        'input',
        'A voting button exists';
    $driver->quit();
    done_testing;