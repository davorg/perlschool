    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;
    use Data::Dumper;

    my $driver = Selenium::Chrome->new();
    print Dumper $driver->get_geolocation;
    print "Not crashed\n";
    $driver->set_geolocation( location => {
        latitude => 40.714353,
        longitude => -74.005973,
    });
    print Dumper $driver->get_geolocation;
    $driver->quit;