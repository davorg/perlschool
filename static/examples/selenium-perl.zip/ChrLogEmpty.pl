    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url = 'http://www.example.com/';
    my $driver = Selenium::Chrome->new();
    my $reflogs = $driver->get_log_types;
    for (0..1) {
        for my $log (@$reflogs) {
            is scalar @{$driver->get_log ($log)}, 0,
                'Empty log returned';
        }
        $driver->get($url) if 0 == $_;
    }
    $driver->quit;
    done_testing;