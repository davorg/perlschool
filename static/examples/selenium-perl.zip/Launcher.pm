    package Launcher;
    use strict; use warnings;
    use Moose;
    use Module::Find;

    has plug => (
        is => 'rw',
    );

    sub _findplugins {
        my ($self, $browsername) = @_;
        my @found = useall Plugins;
        for my $plugin (@found) {
            if ($plugin =~ /::\Q$browsername\E$/i) {
                $self->{plug} = $plugin;
                last;
            }
        }
    }

    sub launch {
        my ($self, $browsername, $hr_params) = @_;
        my %params;
        %params = %$hr_params if defined $hr_params;
        $self->_findplugins($browsername);
        my $object = $self->plug->new(%params);
        return $object->driver;
    }
    1;