    use strict; use warnings;
    use Selenium::Remote::Driver;
    use Test::More;
    use lib ".";
    use Launcher;

    my $url = 'http://www.perlmonks.org';
    my $launcher = Launcher->new();
    for my $browser ('Chrome', 'Firefox') {
        my $driver = $launcher->launch($browser);
        $driver->get('http://www.perlmonks.org');
        is $driver->get_title(),
            'PerlMonks - The Monastery Gates',
            "Title as expected for $browser";
        $driver->close();
    }