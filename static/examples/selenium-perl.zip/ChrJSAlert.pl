    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url = 'http://www.example.com';
    my $jsAlert = <<'END_OF_ALERT';
    var rtn = alert("We use cookies. OK accepts this.");
    localStorage.setItem("JSSelenium", rtn);
END_OF_ALERT

    my $jsGetItem = <<'END_OF_GET';
    return localStorage.getItem("JSSelenium");
END_OF_GET

    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    $driver->execute_script($jsAlert);
    $driver->accept_alert;
    my $rtn = $driver->execute_script($jsGetItem);
    is $rtn, 'undefined',
        'Accepting an alert returns nothing';
    $driver->execute_script($jsAlert);
    $driver->dismiss_alert;
    $driver->execute_script($jsGetItem);
    is $rtn, 'undefined',
        'Dismissing an alert also returns nothing';
    $driver->quit;
    done_testing;