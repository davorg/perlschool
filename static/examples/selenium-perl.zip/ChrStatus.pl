    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $driver = Selenium::Chrome->new();
    for my $key ('os', 'build') {
        ok grep(/$key/, keys %{$driver->status}),
            "Found $key";
    }
    is scalar keys %{$driver->status}, 2, 
        'No strange keys';
    $driver->quit;
    done_testing;