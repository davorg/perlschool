    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://getbootstrap.com';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->find_element(
        'h1.mb-3.bd-text-purple-bright',
        'css');
    is $elt->get_text(),
        'Bootstrap',
        'Masthead found by CSS';
    $driver->quit();
    done_testing;