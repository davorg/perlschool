    use strict; use warnings;
    use Selenium::Chrome;
    my $driver = Selenium::Chrome->new();