    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url = 'https://jqueryui.com/droppable/';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $frame =
        $driver->find_element
        (q<//iframe[@class='demo-frame']>);
    $driver->switch_to_frame($frame);
    my $from = $driver->find_element(
        'draggable', 'id');
    my $to   = $driver->find_element(
        'droppable', 'id');
    my $from_loc = $from->get_element_location;
    my $to_loc = $to ->get_element_location;
    ok ((($$from_loc{x} != $$to_loc{x})
      or ($$from_loc{y} != $$to_loc{y})),
        'One of the starting co-ordinates differs');
    $driver->move_to(element => $from);
    $driver->button_down;
    $driver->mouse_move_to_location (element => $to);
    $driver->button_up;
    my $new_loc = $from->get_element_location;
    ok ((($$from_loc{x} != $$new_loc{x})
      or ($$from_loc{y} != $$new_loc{y})),
        'At least one co-ordinate has changed');
    sleep 10;
    $driver->quit;
    done_testing;