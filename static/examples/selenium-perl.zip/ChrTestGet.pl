    use strict; use warnings;
    use Selenium::Chrome;
    use Test::More;

    my $url = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    is $driver->get_title(),
        'PerlMonks - The Monastery Gates',
        'Title as expected';
    $driver->quit();
    done_testing;