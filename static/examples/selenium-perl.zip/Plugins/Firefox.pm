    package Plugins::Firefox;
    use strict; use warnings;
    use Selenium::Firefox;
    use Moose;
    use namespace::autoclean;

    has driver => (
        is => 'rw',
    );
    sub BUILD {
        my $self = shift;
        my %args = %$_[0];
        $self->{driver} =
            Selenium::Firefox->new(%args);
    }
    __PACKAGE__->meta->make_immutable;
    1;