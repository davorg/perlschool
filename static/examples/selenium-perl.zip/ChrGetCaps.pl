    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $driver = Selenium::Chrome->new();
    is $driver->get_capabilities()->{browserName},
        'chrome', 'Correct browser';
    my $keycount = scalar keys %{$driver->
        get_capabilities()};
    cmp_ok $keycount, '>', 10, 
        "Lots of elements ($keycount)";
    $driver->quit;
    done_testing;