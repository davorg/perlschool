    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->find_element(
        'Voting_Booth', 'id');
    my $count = scalar
        @{$driver->find_child_elements(
            $elt, 'input', 'tag_name')} - 3;
    cmp_ok $count, '>', 2,
        "The poll has at least 2 options ($count)";
    $driver->quit();
    done_testing;