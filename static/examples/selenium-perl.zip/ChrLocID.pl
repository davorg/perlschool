    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->find_element(
        'Voting_Booth', 'id');
    unlike $elt->get_text(),
        '/No recent polls found/i',
        'There is a current poll';
    $driver->quit();
    done_testing;