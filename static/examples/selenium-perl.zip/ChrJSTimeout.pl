    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url = 'http://www.example.com';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    $driver->set_async_script_timeout(2000);
    my $rtn = eval
        {$driver->execute_async_script('');};
    like $$rtn{message}, '/timeout/i', 
        'Empty JS times out';
    print $$rtn{message} . "\n";
    $driver->quit;
    done_testing;