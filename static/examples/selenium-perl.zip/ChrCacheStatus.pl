    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.example.com/';
    my @STATUS = ('UNCACHED', 'IDLE', 'CHECKING',
                  'DOWNLOADING', 'UPDATE_READY', 'OBSOLETE');
    my $driver = Selenium::Chrome->new();
    my $idx = $driver->cache_status;
    is $STATUS[$idx], 'IDLE',
        'Nothing to see yet';
    $driver->get($url);
    $idx = $driver->cache_status;
    use Data::Dumper;
    print Dumper $idx;
    $driver->quit;
    done_testing;