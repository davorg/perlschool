    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $errcroak = eval {
        my $eltcroak = $driver->
            find_element('Cthulhu', 'id');
        1};
    ok $errcroak, "Test should croak";
    print $@ unless $errcroak;
    $errcroak = eval {
        my $eltcroak = $driver->
            find_element('Voting_Booth', 'id');
        1};
    ok $errcroak, "Test should NOT croak";
    print $@ unless $errcroak;
    $driver->quit();
    done_testing;