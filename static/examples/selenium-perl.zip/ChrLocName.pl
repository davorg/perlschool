    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->find_element('passwd', 'name');
    is $elt->get_attribute ('maxlength'), 10,
        'Still no increase in password length';
    $driver->quit();
    done_testing;