    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_input_disabled';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $frame = $driver->find_element(
        qw{//iframe[@name='iframeResult']});
    $driver->switch_to_frame ($frame);
    my $elt = $driver->find_element('fname', 'name');
    ok $elt->is_enabled, 'First name is enabled';
    $elt = $driver->find_element('lname', 'name');
    ok !$elt->is_enabled, 'Last name is disabled';
    $driver->quit();
    done_testing;