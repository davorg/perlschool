    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->find_element(
        'search_text', 'id');
    my $hr = $elt->get_size();
    is $hr->{height}, 21,
        'Search text box height does not change';
    is $hr->{width}, 173,
        'Search text box width does not change';
    $driver->quit();
    done_testing;