    use strict; use warnings;
    use feature 'say';
    use Selenium::Chrome;
    my $url = 'http://www.perlmonks.org';

    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    say $driver->get_title();
    $driver->quit();