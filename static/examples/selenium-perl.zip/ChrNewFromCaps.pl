    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.example.com/';
    my $driver = Selenium::Chrome->new();
    my $hr_caps = $driver->get_capabilities();
    $driver->quit;
    $hr_caps->{'unexpectedAlertBehaviour'} 
        = 'ignore';
    refeval($hr_caps);
    delete $hr_caps->{acceptInsecureCerts};
    $driver = Selenium::Chrome->new_from_caps(
        'desired_capabilities' => {%$hr_caps});
    $driver->get($url);
    is $driver->get_title(), 'Example Domain',
        'Title correct';
    $hr_caps = $driver->get_capabilities();
    refeval($hr_caps);
    is $hr_caps->{'unexpectedAlertBehaviour'},
        'ignore', 'Capability as set';
    $driver->quit;
    done_testing;

    sub refeval {
        my $href = shift;
        for my $key(keys %$href) {
            if ('HASH' eq ref($href->{$key})) {
                refeval($href->{$key});
            } elsif ('' ne ref($href->{$key})) {
                $href->{$key} = eval($href->{$key});
            }
        }
    }