    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.freeformatter.com';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $ar_cook = $driver->get_all_cookies();
    is scalar @$ar_cook, 2, 
        'Freeformatter uses 2 cookies';
    $driver->delete_all_cookies;
    $ar_cook = $driver->get_all_cookies();
    is scalar @$ar_cook, 0, 'All gone';
    $driver->refresh;
    $ar_cook = $driver->get_all_cookies();
    is scalar @$ar_cook, 2, 
        '... but refreshing replaces them.';
    $driver->quit;
    done_testing;