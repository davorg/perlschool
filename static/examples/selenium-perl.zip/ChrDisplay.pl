    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->find_element('op', 'name');
    ok $elt->is_hidden(), '"op" element is hidden';
    ok !$elt->is_displayed(), 
        '"op" element is not displayed';
    $elt = $driver->find_element('user', 'name');
    ok $elt->is_displayed(), 
        '"user" element is displayed';
    ok !$elt->is_hidden(), 
        '"user" element is not hidden';
    $driver->quit();
    done_testing;