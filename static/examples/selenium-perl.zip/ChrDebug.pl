    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.example.com/';
    my $driver = Selenium::Chrome->new();
    $driver->debug_on;
    $driver->get($url);
    $driver->debug_off;
    $driver->refresh;
    $driver->quit;