    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.example.com/';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $page = $driver->get_page_source;
    like $page, qr/You may use this/, 'OK to use';
    my $body = $driver->get_body;
    my $pagelen = length($page);
    my $bodylen = length($body);
    cmp_ok $pagelen, ">", $bodylen,
        "Page longer than body ($pagelen>$bodylen)";
    my $elt = $driver->find_element(
        'body', 'tag_name')->get_text;
    is $elt, $body, 
        'get_body is simpler than using the driver';
    $driver->quit;
    done_testing;