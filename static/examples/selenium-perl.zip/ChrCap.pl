    use strict; use warnings;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    $driver->capture_screenshot('PMHome.png');
    $driver->quit();