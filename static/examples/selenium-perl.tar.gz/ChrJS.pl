    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $driver = Selenium::Chrome->new();
    ok $driver->has_javascript, 
        'Javascript is enabled';
    $driver->quit;
    done_testing;