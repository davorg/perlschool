    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $driver = Selenium::Chrome->new();
    my $reflogs = $driver->get_log_types;
    my $logcount = scalar @$reflogs;
    cmp_ok $logcount, '>', 3,
        "At least 4 logs available ($logcount)";
    for my $log 
    ('browser', 'client', 'driver', 'server') {
        ok grep(/$log/, @$reflogs), "Found $log";
    }
    $driver->quit;
    done_testing;