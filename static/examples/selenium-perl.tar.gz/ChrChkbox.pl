    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_input_checked';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $frame = $driver->find_element(
        qw{//iframe[@name='iframeResult']});
    $driver->switch_to_frame($frame);
    $driver->find_element(
        q<//input[@value='Bike']>)->click;
    $driver->find_element(
        q<//input[@value='Submit']>)->click;
    $frame = $driver->find_element(
        qw{//iframe[@name='iframeResult']});
    $driver->switch_to_frame($frame);
    my $elt = $driver->find_element(
        "//body[\@class='w3-container']/div");
    is $elt->get_text(),
        'vehicle=Bike&vehicle=Car ',
        'Both boxes selected';
    $driver->quit();
    done_testing;