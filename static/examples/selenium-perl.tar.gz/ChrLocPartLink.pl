    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->find_element('oting',
        'partial_link_text');
    like $elt->get_text(),
        '/experience/i',
        'Link to voting & experience system';
    $driver->quit();
    done_testing;