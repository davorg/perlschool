    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $driver = Selenium::Chrome->new();
    my $orighigh = $driver->
        get_window_size()->{height};
    my $origwide = $driver->
        get_window_size()->{width};
    my $origx    = $driver->
        get_window_position()->{x};
    my $origy    = $driver->
        get_window_position()->{y};
    my $changes = 0;
    $driver->maximize_window;
    sleep 1;

    $changes++ if $driver->
        get_window_size()->{height} != $orighigh;
    $changes++ if $driver->
        get_window_size()->{width}  != $origwide;
    $changes++ if $driver->
        get_window_position()->{x}  != $origx;
    $changes++ if $driver->
        get_window_position()->{y}  != $origy;
    cmp_ok $changes, ">", 0,
        "At least one attribute has changed ($changes)";

    $driver->set_window_size($orighigh, $origwide);
    $driver->set_window_position($origx, $origy);
    sleep 1;

    is $driver->get_window_size()->{height},
        $orighigh, 'Height has original value';
    is $driver->get_window_size()->{width} ,
        $origwide, 'Width has original value';
    is $driver->get_window_position()->{x} ,
        $origx,    'X co-ord has original value';
    is $driver->get_window_position()->{y} ,
        $origy,    'Y co-ord has original value';
    $driver->quit();
    done_testing;