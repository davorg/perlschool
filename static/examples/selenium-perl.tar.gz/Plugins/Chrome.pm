    package Plugins::Chrome;
    use strict; use warnings;
    use Selenium::Chrome;
    use Moose;
    use namespace::autoclean;

    has driver => (
        is => 'rw',
    );
    sub BUILD {
        my $self = shift;
        my %args = %$_[0];
        $self->{driver} =
            Selenium::Chrome->new(%args);
    }
    __PACKAGE__->meta->make_immutable;
    1;