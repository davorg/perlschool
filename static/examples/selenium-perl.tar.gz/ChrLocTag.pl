    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->find_element('a',
        'tag_name');
    is $elt->get_attribute('href'),
        'http://pair.com/',
        'First link is to Pair';
    $driver->quit();
    done_testing;