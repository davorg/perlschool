    use strict; use warnings;
    use Selenium::Chrome;
    use Test::More;

    my $url    = 'http://www.perlmonks.org';
    my $link   = 'Recently Active Threads';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    $driver->find_element_by_link_text($link)->click;
    is $driver->get_title(),
        'Recently Active Threads',
        'Title as expected';
    $driver->quit();
    done_testing;