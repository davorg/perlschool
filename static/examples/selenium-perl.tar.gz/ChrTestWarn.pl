    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;
    use Test::Warnings;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    for ('Cthulhu', 'Voting_Booth') {
        my $elt = $driver->find_element_by_id($_);
        if (0 == $elt) {
            fail "Couldn't find element $_";
        } else {
            is $elt->get_attribute('id'), $_,
                "Found $_";
        }
    }
    $driver->quit();
    done_testing;