    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url = 'http://www.example.com';
    my $jsPrompt = <<'END_OF_PROMPT';
    var rtn = prompt("How many cookies may we set?");
    localStorage.setItem("JSSelenium", rtn);
END_OF_PROMPT

    my $jsGetItem = <<'END_OF_GET';
    return localStorage.getItem("JSSelenium");
END_OF_GET

    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    for my $str ('1', '') {
        $driver->execute_script($jsPrompt);
        $driver->send_keys_to_prompt ($str);
        $driver->accept_alert;
        my $rtn = $driver->execute_script(
            $jsGetItem);
        is $rtn, $str, 
            "<$str> and accept returned correctly";
    }
    $driver->execute_script($jsPrompt);
    $driver->dismiss_alert;
    my $rtn = $driver->execute_script($jsGetItem);
    is $rtn, 'null', 
        "Dismissing a confirmation returns null";
    $driver->quit;
    done_testing;