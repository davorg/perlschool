    use strict; use warnings;
    use Selenium::Chrome;
    use feature 'say';

    my $url    = 'http://www.example.com/';
    my $driver = Selenium::Chrome->new(
        error_handler => sub {
            warn @_;
            warn 'Warned by custom error handler';
        }
    );
    $driver->get($url);
    $driver->get_local_storage_item('JSSelenium');
    $driver->error_handler(
        sub {
            say @_;
            say 'Logged by custom error handler';
        }
    );
    $driver->get_local_storage_item('JSSelenium');
    $driver->clear_error_handler;
    $driver->get_local_storage_item('JSSelenium');
    say 'This line not reached';