    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.google.com';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    is $driver->get_active_element()->
        get_attribute('name'),
        'q',
        'Google query box activated by default';
    $driver->quit();
    done_testing;