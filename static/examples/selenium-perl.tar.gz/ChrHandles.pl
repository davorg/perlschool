    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;
    use Selenium::Remote::WDKeys 'KEYS';

    my $url  = 'http://www.perlmonks.org';
    my $link = 'Recently Active Threads';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $orighdl = $driver->
        get_current_window_handle;
    $driver->find_element_by_link_text($link)->
        send_keys(KEYS->{'control'},
            KEYS->{'enter'});
    my $handles = $driver->get_window_handles;
    if ($driver->get_current_window_handle
        ne $orighdl) {
        $driver->switch_to_window($handles->[0]);
    }
    is $driver->get_title(),
        'PerlMonks - The Monastery Gates',
        'Title as expected';
    $driver->switch_to_window($handles->[1]);
    is $driver->get_title(),
        'Recently Active Threads',
        'Title of second tab as expected';
    $driver->quit;
    done_testing;