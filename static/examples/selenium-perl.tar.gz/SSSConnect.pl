    use strict; use warnings;
    # use Selenium::Remote::Driver;
    use Selenium::Chrome;
    use Test::More;

    my $url = 'http://www.perlmonks.org';
    # my $driver = Selenium::Remote::Driver->new(
    my $driver = Selenium::Chrome->new(
        remote_server_addr => '127.0.0.1',
        port               => '4444',
      # browser_name       => 'chrome'
    );
    $driver->get($url);
    is $driver->get_title(),
        'PerlMonks - The Monastery Gates',
        'Title as expected';
    $driver->quit();
    done_testing;