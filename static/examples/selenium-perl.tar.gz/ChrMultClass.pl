    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my @elt1 = $driver->find_elements(
        'post-voterep', 'class_name');
    my @elt2 = $driver->find_elements(
        'superdoc' , 'class_name');
    my $num = scalar @elt1;
    cmp_ok $num, '>', 5, "More than 5 posts ($num)";
    is scalar @elt2, 1, 'Only one superdoc';
    $driver->quit();
    done_testing;