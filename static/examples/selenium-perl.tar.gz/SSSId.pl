    use strict; use warnings;
    use Selenium::Remote::Driver;
    use Test::More;

    my $url = 'http://www.perlmonks.org';
    for my $name (# 'phantomjs', 'firefox',
        # 'internet explorer', 'MicrosoftEdge',
        # 'safari', 'iphone',
        'htmlunit', 'chrome') {
        my $driver = Selenium::Remote::Driver->new(
            remote_server_addr => '127.0.0.1',
            port               => '4444',
            browser_name       => $name
        );
        $driver->get($url);
        is $driver->get_title(),
            'PerlMonks - The Monastery Gates',
            "Title as expected for $name";
        is $driver->get_capabilities()->{browserName},
            $name, 'Correct browser';
        $driver->quit();
    }
    done_testing;