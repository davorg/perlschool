    use strict; use warnings;
    use Selenium::Chrome;
    use Selenium::Screenshot;

    my $url     = 'http://www.perlmonks.org';
    my $outdir  = '.';
    my $outfile = 'scrshot';
    my $driver  = Selenium::Chrome->new();
    $driver->get($url);
    my $pic = Selenium::Screenshot->new(
        png => $driver->screenshot,
        folder => $outdir,
    )->save(filename => $outfile);
    $driver->quit();