    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url  = 'http://www.perlmonks.org';
    my $link = 'Recently Active Threads';
    my @drivers;
    push @drivers, Selenium::Chrome->new();
    $drivers[0]->get($url);
    my $linkurl = $drivers[0]->
        find_element_by_link_text($link)->
        get_attribute('href');
    push @drivers, Selenium::Chrome->new();
    $drivers[1]->get($linkurl);
    is $drivers[1]->get_title(),
        'Recently Active Threads',
        'Title as expected';
    sleep 5;
    for (@drivers) {
        $_->quit;
    }
    done_testing;