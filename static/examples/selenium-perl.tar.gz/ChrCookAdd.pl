    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.example.com';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $ar_cook = $driver->get_all_cookies();
    is scalar @$ar_cook, 0, 
        'Example.com uses no cookies';
    $driver->add_cookie('cookiename',
        'cookievalue',
        '/',
        '.example.com');
    $ar_cook = $driver->get_all_cookies();
    is scalar @$ar_cook, 1, '1 cookie now';
    is $$ar_cook[0]{name}, 'cookiename',
        'The added cookie has the right name ...';
    is $$ar_cook[0]{value}, 'cookievalue', 
        '... and value';
    $driver->quit;
    done_testing;