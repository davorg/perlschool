    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url = 'http://www.example.com';
    my $jsAlert = <<'END_OF_ALERT';
    var rtn = alert("We use cookies. OK accepts this.");
    localStorage.setItem("JSSelenium", rtn);
END_OF_ALERT

    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    $driver->execute_script($jsAlert);
    my $rtn = $driver->get_alert_text;
    is $rtn, 'We use cookies. OK accepts this.',
        'Text generated correctly';
    $driver->accept_alert;
    $driver->quit;
    done_testing;