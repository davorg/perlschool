    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'https://www.w3schools.com/html/tryit.asp?filename=tryhtml_form_radio';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $frame = $driver->find_element(
        qw{//iframe[@name='iframeResult']});
    $driver->switch_to_frame($frame);
    is $driver->find_element(
        q<//input[@value='male']>)
        ->get_attribute('checked'), 'true',
        '"male" is true before click';
    is $driver->find_element(
        q<//input[@value='female']>)
        ->get_attribute('checked'), undef,
        '"female" is undef before click';
    is $driver->find_element(
        q<//input[@value='other']>)
        ->get_attribute('checked'), undef,
        '"other" is undef before click';
    $driver->find_element(
        q<//input[@value='other']>)->click;

    is $driver->find_element(
        q<//input[@value='male']>)
        ->get_attribute('checked'), undef,
        '"male" is undef after click';
    is $driver->find_element(
        q<//input[@value='female']>)
        ->get_attribute('checked'), undef,
        '"female" is undef after click';
    is $driver->find_element(
        q<//input[@value='other']>)
        ->get_attribute('checked'), 'true',
        '"other" is true after click';
    $driver->quit();
    done_testing;