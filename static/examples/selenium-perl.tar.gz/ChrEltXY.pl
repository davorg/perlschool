    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->find_element(
        'search_text', 'id');
    my $hash = $elt->get_element_location();
    cmp_ok $$hash{x}, ">", 10,
        "X co-ordinate reasonable ($$hash{x})";
    cmp_ok $$hash{y}, ">", 50,
        "Y co-ordinate reasonable ($$hash{y})";
    $driver->quit();
    done_testing;