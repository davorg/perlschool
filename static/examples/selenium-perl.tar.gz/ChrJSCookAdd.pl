    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url = 'http://www.example.com/';
    my $js = <<'END_OF_JS';
    document.cookie = "testcookie=testvalue; path=/; domain= .example.com;expires=27 Nov 2027 00:00:01 UTC";
END_OF_JS

    my $driver = Selenium::Chrome->new();
    SKIP: {
        skip "Can't test JS (disabled)", 5 
          unless $driver->has_javascript;
        $driver->delete_all_cookies;
        $driver->get($url);
        my $ar_cook = $driver->get_all_cookies();
        is scalar @$ar_cook, 0, 
          'Example.com uses no cookies';
        $driver->execute_script($js);
        $ar_cook = $driver->get_all_cookies();
        is scalar @$ar_cook, 1, '1 cookie now';
        is $$ar_cook[0]->{name}, 'testcookie',
          'The added cookie has the right name ...';
        is $$ar_cook[0]->{value}, 'testvalue', 
          '... and value ...';
        is $$ar_cook[0]->{expiry}, 1827273601, 
          '... and expiry!';
    }
    $driver->delete_all_cookies;
    $driver->quit;
    done_testing;