    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url = 'http://www.example.com';
    my $jsConfirm = <<'END_OF_CONFIRM';
    var rtn = confirm("We use cookies. OK lets us.");
    localStorage.setItem("JSSelenium", rtn);
END_OF_CONFIRM

    my $jsGetItem = <<'END_OF_GET';
    return localStorage.getItem("JSSelenium");
END_OF_GET

    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    $driver->execute_script($jsConfirm);
    $driver->accept_alert;
    my $rtn = $driver->execute_script($jsGetItem);
    is $rtn, 'true', 
        "Accepting a confirmation returns true";
    $driver->execute_script($jsConfirm);
    $driver->dismiss_alert;
    $rtn = $driver->execute_script($jsGetItem);
    is $rtn, 'false', 
        "Dismissing a confirmation returns false";
    $driver->quit;
    done_testing;