    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.freeformatter.com';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $ar_cook = $driver->get_all_cookies();
    my $n = scalar @$ar_cook;
    is $n, 2, 'Freeformatter uses 2 cookies';
    my %cookies;
    for (@$ar_cook) {
        $cookies{$_->{name}} = $_->{value};
    }
    ok exists $cookies{AWSELB}, 
        'Found Amazon cookie at freeformatter';
    $driver->quit;
    done_testing;