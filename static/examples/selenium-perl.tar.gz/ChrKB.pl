    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;
    use Selenium::Remote::WDKeys 'KEYS';

    my $url    = 'http://www.google.com';
    my $text   = 'Perl Monks';
    my $xpath  = q<//input[@name='q']>;
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    $driver->find_element($xpath)->
        send_keys($text, KEYS->{'enter'});
    is $driver->get_title(),
        'Perl Monks - Google Search',
        'Title as expected';
    $driver->quit();
    done_testing;