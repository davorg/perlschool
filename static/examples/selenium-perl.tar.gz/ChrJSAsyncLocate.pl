    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url = 'http://www.perlmonks.org';
    my $js = <<'END_OF_JS';
    var id = arguments[0];
    var callback = arguments[arguments.length-1];
    var elt = document.getElementById(id);
    callback(elt);
END_OF_JS

    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->execute_async_script
        ($js, 'Log_In');
    like $elt->get_text, '/^Log In/', 
        'Login table found';
    $driver->quit;
    done_testing;