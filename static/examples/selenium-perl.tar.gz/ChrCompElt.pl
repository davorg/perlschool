    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->find_element(
        'post-voterep', 'class_name');
    my $doc = $driver->find_element_by_class_name(
        'superdoc');
    ok !$driver->compare_elements($elt, $doc),
        'The superdoc is not a post';
    $driver->quit();
    done_testing;