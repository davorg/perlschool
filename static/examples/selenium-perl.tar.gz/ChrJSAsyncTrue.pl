    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url = 'http://www.perlmonks.org';
    my $js = <<'END_OF_JS';
    var delay = arguments[0];
    var id = arguments[1];
    var callback = arguments[arguments.length-1];
    setTimeout(function(){
        var elt = document.getElementById(id);
        callback(elt);
    }, delay * 1000);
END_OF_JS

    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->execute_async_script
        ($js, 5, 'Log_In');
    like $elt->get_text, '/^Log In/', 
        'Login table found';
    $driver->quit;
    done_testing;