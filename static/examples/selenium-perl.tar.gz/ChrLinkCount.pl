    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my @elt = $driver->find_elements('oting',     
        'partial_link_text');
    is scalar @elt, 1, 'Only 1 voting link';
    $driver->quit();
    done_testing;