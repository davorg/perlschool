    use strict; use warnings;
    use feature 'say';
    use Selenium::Remote::Driver;

    my $driver = Selenium::Remote::Driver->new(
        'port' => 4444,
        'browser_name' => 'safari'
    );
    $driver->get('http://www.perlmonks.org');
    say $driver->get_title();
    $driver->quit();