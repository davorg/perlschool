    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url = 'http://www.perlmonks.org';
    my $js = <<'END_OF_JS';
    return document.getElementById('Log_In');
END_OF_JS

    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt = $driver->execute_script($js);
    like $elt->get_text(), '/^Log In/i',
        'Login table found';
    $driver->quit;
    done_testing;