    use strict; use warnings;
    use Selenium::Chrome;
    use MIME::Base64;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $b64 = $driver->screenshot();
    my $decoded = decode_base64($b64);
    open my $fh, '>', 'PMB64.png'
        or die "Can't open PMB64.png for output: $!";
    binmode $fh, ':raw';
    print $fh $decoded;
    close $fh;
    $driver->quit();