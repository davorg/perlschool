    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_select';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    $driver->switch_to_frame($driver->find_element(
        qw{//iframe[@name='iframeResult']}));
    my $elt = $driver->find_element(
        'option', 'tag_name');
    ok $elt->is_selected(), 'First option selected';
    is $elt->get_attribute('value'), 'volvo',
        'First option is Volvo';
    $driver->quit();
    done_testing;