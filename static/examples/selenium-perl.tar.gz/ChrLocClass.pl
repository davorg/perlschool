    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;

    my $url    = 'http://www.perlmonks.org';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);
    my $elt1 = $driver->find_element_by_class_name(
        'post-voterep');
    my $elt2 = $driver->find_element(
        'post-voterep', 'class_name');
    is_deeply $elt1, $elt2, 
        'Find element format doesn\'t matter';
    my $doc = $driver->find_element_by_class_name(
        'superdoc');
    isn't $elt1->get_text,
        $doc->get_text,
        'Looking at different elements';
    is $doc->get_text,
        'The Monastery Gates',
        'h3 is a superdoc with TMG title';
    $driver->quit();
    done_testing;