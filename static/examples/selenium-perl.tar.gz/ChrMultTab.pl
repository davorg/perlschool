    use strict; use warnings;
    use Test::More;
    use Selenium::Chrome;
    use Selenium::Remote::WDKeys 'KEYS';

    my $url  = 'http://www.perlmonks.org';
    my $link = 'Recently Active Threads';
    my $driver = Selenium::Chrome->new();
    $driver->get($url);

    $driver->find_element_by_link_text($link)->
        send_keys(KEYS->{'control'},
        KEYS->{'enter'});
    is $driver->get_title(),
        'PerlMonks - The Monastery Gates',
        'Title as expected';
    my $handles = $driver->get_window_handles;
    $driver->switch_to_window($handles->[1]);
    is $driver->get_title(),
        'Recently Active Threads',
        'Title of second tab as expected';
    $driver->quit;
    done_testing;