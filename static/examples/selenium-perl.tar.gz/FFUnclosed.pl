    use strict; use warnings;
    use Selenium::Firefox;
    my $driver = Selenium::Firefox->new();