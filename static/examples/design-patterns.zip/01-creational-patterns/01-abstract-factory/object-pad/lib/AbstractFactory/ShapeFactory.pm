use Shape::Square;
use Shape::Rectangle;

use Object::Pad;

class AbstractFactory::ShapeFactory :does(AbstractFactory) {
    method getShape($shapeType) {
        if (uc($shapeType) eq 'RECTANGLE') {
            return Shape::Rectangle->new;
        }
        elsif (uc($shapeType) eq 'SQUARE') {
            return Shape::Square->new;
        }
        return;
    }
}

1;
