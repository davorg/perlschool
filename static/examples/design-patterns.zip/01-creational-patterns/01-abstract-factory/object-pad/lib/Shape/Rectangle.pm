use Object::Pad;

class Shape::Rectangle :does(Shape) {
    method draw { 'Inside Shape::Rectangle::draw()' }
}

1;
