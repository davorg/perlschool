use Object::Pad;

class Shape::Square :does(Shape) {
    method draw { 'Inside Shape::Square::draw()' }
}

1;
