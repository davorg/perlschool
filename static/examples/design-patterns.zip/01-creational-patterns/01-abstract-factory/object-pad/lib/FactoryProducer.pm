use Object::Pad;
use AbstractFactory::ShapeFactory;
use AbstractFactory::RoundedShapeFactory;

class FactoryProducer {
    method getFactory($rounded) {
        return $rounded
            ? AbstractFactory::RoundedShapeFactory->new
            : AbstractFactory::ShapeFactory->new;
    }
}

1;
