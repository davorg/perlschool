package Shape::RoundedRectangle;

use Moo;
with qw/Shape/;

sub draw { 'Inside Shape::RoundedRectangle::draw()' }

1;
