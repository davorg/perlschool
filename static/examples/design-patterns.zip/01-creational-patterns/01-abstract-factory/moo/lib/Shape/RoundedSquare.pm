package Shape::RoundedSquare;

use Moo;
with qw/Shape/;

sub draw { 'Inside Shape::RoundedSquare::draw()' }

1;
