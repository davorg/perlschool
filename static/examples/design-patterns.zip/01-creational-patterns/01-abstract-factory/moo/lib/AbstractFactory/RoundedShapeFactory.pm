package AbstractFactory::RoundedShapeFactory;

use Shape::RoundedSquare;
use Shape::RoundedRectangle;

use Moo;
with qw/AbstractFactory/;

sub getShape {
    my ($self, $shapeType) = @_;

    if (uc($shapeType) eq 'RECTANGLE') {
        return Shape::RoundedRectangle->new;
    }
    elsif (uc($shapeType) eq 'SQUARE') {
        return Shape::RoundedSquare->new;
    }
    return;
}

1;
