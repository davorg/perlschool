package Shape::RoundedRectangle;

use Class;
with qw/Shape/;

sub draw { 'Inside Shape::RoundedRectangle::draw()' }

1;
