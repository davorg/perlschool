package Shape::RoundedSquare;

use Class;
with qw/Shape/;

sub draw { 'Inside Shape::RoundedSquare::draw()' }

1;
