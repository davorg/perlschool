package AbstractFactory;

use Role;
requires qw/getShape/;

1;
