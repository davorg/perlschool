package FactoryProducer;

use AbstractFactory::ShapeFactory;
use AbstractFactory::RoundedShapeFactory;

use Class;

sub getFactory {
    my ($self, $rounded) = @_;

    return $rounded
        ? AbstractFactory::RoundedShapeFactory->new
        : AbstractFactory::ShapeFactory->new;
}

1;
