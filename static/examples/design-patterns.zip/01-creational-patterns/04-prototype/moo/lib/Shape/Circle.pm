package Shape::Circle;

use Moo;
extends qw/Shape/;

has 'type'   => (
    is       => 'ro',
    required => 1,
    default  => sub { 'Circle' },
);

sub draw { 'Inside Shape::Circle::draw()' }

1;
