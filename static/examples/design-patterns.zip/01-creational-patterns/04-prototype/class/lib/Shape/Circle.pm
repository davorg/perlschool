use v5.42;
use experimental qw/class/;

class Shape::Circle :isa(Shape)    {
    field $type :reader :param = 'Circle';

    method draw { 'Inside Shape::Circle::draw()' }
}

1;
