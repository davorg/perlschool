use v5.42;
use experimental 'class';

class Shape {
    field $id :param :reader;

    method clone {
        my $class = ref $self;
        return $class->new(id => $self->id);
    }
}

1;
