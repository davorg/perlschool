use v5.42;
use experimental 'class';

class ShapeCache {
    use Shape::Circle;
    use Shape::Square;
    use Shape::Rectangle;

    field %shapes;

    ADJUST {
        %shapes = (
            1 => Shape::Circle->new(id => 1),
            2 => Shape::Square->new(id => 2),
            3 => Shape::Rectangle->new(id => 3),
        );
    }

    method getShape($id) {
        return $shapes{$id}->clone;
    }
}

1;
