package ShapeCache;

use Class;
use Shape::Circle;
use Shape::Square;
use Shape::Rectangle;

sub BUILD {
    my ($self, $args) = @_;

    $self->{shapes} = {
        1 => Shape::Circle->new(id => 1),
        2 => Shape::Square->new(id => 2),
        3 => Shape::Rectangle->new(id => 3),
    }
}

sub getShape {
    my ($self, $id) = @_;
    $self->{shapes}->{$id}->clone;
}

1;
