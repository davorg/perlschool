package Shape;

use Class;
use Class::Clone;

sub BUILD { die "Missing required key 'id'.\n" unless (exists shift->{id}) }
sub id { shift->{id} }

1;
