package Shape::Square;

use Class;
extends qw/Shape/;

sub BUILD {
    my ($self) = @_;
    $self->{type} //= 'Square';
}

sub draw  { 'Inside Shape::Square::draw()' }
sub type  { shift->{type} }
1;
