package Shape::Rectangle;

use Class;
extends qw/Shape/;

sub BUILD {
    my ($self) = @_;
    $self->{type} //= 'Rectangle';
}
sub draw { 'Inside Shape::Rectangle::draw()' }
sub type { shift->{type} }
1;
