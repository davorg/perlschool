package Shape::Circle;

use Class;
extends qw/Shape/;

sub BUILD {
    my ($self) = @_;
    $self->{type} //= 'Circle'
};

sub draw { 'Inside Shape::Circle::draw()' }
sub type { shift->{type} }
1;
