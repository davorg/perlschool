use Object::Pad;

class Meal {
    field @items;

    method addItem($item) { push @items, $item }

    method getCost {
        my $cost = 0;
        $cost += $_->price for @items;
        return $cost;
    }

    method getItems {
        [ map [ $_->name, $_->packing->pack, $_->price ], @items ];
    }
}

1;
