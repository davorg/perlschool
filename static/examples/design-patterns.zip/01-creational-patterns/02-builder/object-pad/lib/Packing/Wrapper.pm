use Object::Pad;

class Packing::Wrapper :does(Packing) {
    method pack { 'Wrapper' }
}

1;
