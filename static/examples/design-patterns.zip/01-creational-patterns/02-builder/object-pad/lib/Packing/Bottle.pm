use Object::Pad;

class Packing::Bottle :does(Packing) {
    method pack { 'Bottle'  }
}

1;
