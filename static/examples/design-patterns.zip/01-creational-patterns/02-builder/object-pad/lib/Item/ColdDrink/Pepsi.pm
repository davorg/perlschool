use Object::Pad;

class Item::ColdDrink::Pepsi :does(Item::ColdDrink) {
    method name  { 'Pepsi' }
    method price { 14      }
}

1;
