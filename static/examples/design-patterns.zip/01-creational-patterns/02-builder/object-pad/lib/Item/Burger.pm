use Packing::Wrapper;

use Object::Pad;

role Item::Burger :does(Item) {
    method name;
    method price;
    method packing { Packing::Wrapper->new }
}

1;
