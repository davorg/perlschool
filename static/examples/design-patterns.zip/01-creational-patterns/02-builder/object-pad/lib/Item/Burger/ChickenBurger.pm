use Object::Pad;

class Item::Burger::ChickenBurger :does(Item::Burger) {
    method name  { 'Chicken Burger' }
    method price { 20               }
}

1;
