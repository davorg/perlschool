use Object::Pad;

class Item::Burger::VegBurger :does(Item::Burger) {
    method name  { 'Veg Burger'     }
    method price { 10               }
}

1;
