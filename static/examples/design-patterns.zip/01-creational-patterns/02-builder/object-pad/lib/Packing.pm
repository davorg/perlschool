use Object::Pad;

role Packing {
    method pack :required;
}

1;
