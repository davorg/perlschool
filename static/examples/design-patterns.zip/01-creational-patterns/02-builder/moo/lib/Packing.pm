package Packing;

use Moo::Role;
requires qw/pack/;

1;
