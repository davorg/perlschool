package Item::Burger;

use Packing::Wrapper;

use Moo::Role;
with qw/Item/;
requires qw/name price/;

sub packing { Packing::Wrapper->new }

1;
