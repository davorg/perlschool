package Item::ColdDrink::Coke;

use Class;
with qw/Item::ColdDrink/;

sub name  { 'Coke' }
sub price { 12     }

1;
