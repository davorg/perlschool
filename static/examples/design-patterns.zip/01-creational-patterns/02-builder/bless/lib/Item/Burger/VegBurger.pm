package Item::Burger::VegBurger;

use Class;
with qw/Item::Burger/;

sub name  { 'Veg Burger' }
sub price { 10           }

1;
