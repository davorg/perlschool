package Item::Burger::ChickenBurger;

use Class;
with qw/Item::Burger/;

sub name  { 'Chicken Burger' }
sub price { 20               }

1;
