package Item;

use Role;
requires qw/name price packing/;

1;
