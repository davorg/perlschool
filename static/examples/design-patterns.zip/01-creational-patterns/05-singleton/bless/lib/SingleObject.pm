package SingleObject;

use Class;

my $instance;

sub BUILD    { shift->{count} //= 0           }
sub instance { $instance //= __PACKAGE__->new }
sub counter  { ++shift->{count}               }

1;
