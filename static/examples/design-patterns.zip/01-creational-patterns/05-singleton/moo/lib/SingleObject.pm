package SingleObject;

use Moo;
with qw/MooX::Singleton/;

has 'count' => (is => 'rw', default => sub { 0 });

sub counter {
    my ($self) = @_;
    return $self->count($self->count + 1);
}

1;
