use v5.42;
use experimental 'class';

class SingleObject {
    field $count = 0;

    state $instance;

    sub instance   { $instance //= __PACKAGE__->new }
    method counter { ++$count                       }
}

1;
