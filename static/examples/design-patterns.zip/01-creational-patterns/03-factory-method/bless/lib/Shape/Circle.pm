package Shape::Circle;

use Class;
with qw/Shape/;

sub draw { 'Inside Shape::Circle::draw()' }

1;
