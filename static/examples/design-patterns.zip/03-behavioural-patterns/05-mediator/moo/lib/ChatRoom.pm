package ChatRoom;

use Moo;
with qw/ChatRoomMediator/;

has users => (is => 'rw', default => sub {[]});

sub register_user {
    my ($self, $user) = @_;

    push @{$self->users}, $user;
    $user->mediator($self);
}

sub show_message {
    my ($self, $from_user, $message) = @_;

    for my $user (@{$self->users}) {
        next if $user == $from_user;
        $user->receive($from_user, $message);
    }
}

1;
