use Object::Pad;

role ChatRoomMediator {
    method show_message;
}

1;
