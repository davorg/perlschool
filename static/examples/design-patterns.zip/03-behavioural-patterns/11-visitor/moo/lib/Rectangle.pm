package Rectangle;

use Moo;
with qw/Shape/;

has width  => (is => 'ro', required => 1);
has height => (is => 'ro', required => 1);

sub accept {
    my ($self, $visitor) = @_;

    $visitor->visit_rectangle($self);
}

1;
