use Object::Pad;

class Circle :does(Shape) {
    field $radius :param :reader;

    method accept($visitor) { $visitor->visit_circle($self) }
}

1;
