use Object::Pad;

class AreaCalculator :does(Visitor) {
    method visit_circle($circle)  { 3.1416 * $circle->radius ** 2 }
    method visit_rectangle($rect) { $rect->width * $rect->height  }
}

1;
