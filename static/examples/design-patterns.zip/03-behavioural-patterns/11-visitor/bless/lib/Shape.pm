package Shape;

use Role;
requires qw/accept/;

1;
