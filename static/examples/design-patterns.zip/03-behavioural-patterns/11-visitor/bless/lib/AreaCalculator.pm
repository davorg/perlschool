package AreaCalculator;

use Class;
with qw/Visitor/;

sub visit_circle {
    my ($self, $circle) = @_;

    3.1416 * $circle->radius ** 2;
}

sub visit_rectangle{
    my ($self, $rect) = @_;

    $rect->width * $rect->height;
}

1;
