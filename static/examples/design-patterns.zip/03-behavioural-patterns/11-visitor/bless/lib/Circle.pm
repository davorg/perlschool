package Circle;

use Class;
with qw/Shape/;

sub BUILD {
    die "Missing required key 'radius'.\n"
        unless (exists shift->{radius});
}

sub radius { shift->{radius} }

sub accept {
    my ($self, $visitor) = @_;

    $visitor->visit_circle($self);
}

1;
