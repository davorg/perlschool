package Visitor;

use Role;
requires qw/visit_circle visit_rectangle/;

1;
