package Container::NameRepository;

use Class;
with qw/Container/;

use Iterator::Name;

sub BUILD {
    my ($self, $args) = @_;
    die "Missing required key 'names'.\n"
        unless (exists $self->{names});
    $self->{iterator} //= Iterator::Name->new(names => $self->names)
}

sub names       { shift->{names} }
sub getIterator { Iterator::Name->new(names => shift->names) }

1;
