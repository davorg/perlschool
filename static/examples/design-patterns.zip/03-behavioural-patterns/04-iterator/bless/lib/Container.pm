package Container;

use Role;
requires qw/getIterator/;

1;
