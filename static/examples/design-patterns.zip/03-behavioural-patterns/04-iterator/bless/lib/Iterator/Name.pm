package Iterator::Name;

use Class;
with qw/Iterator/;

sub BUILD {
    my ($self) = @_;

    $self->{index} = -1;
}

sub names         { shift->{names} }
sub index :lvalue { shift->{index} }

sub has_next {
    my ($self) = @_;

    ($self->index < scalar(@{$self->names})-1);
}

sub next {
    my ($self) = @_;

    if ($self->has_next) {
        $self->index++;
        return $self->names->[$self->index];
    }
    return;
}

1;
