use v5.42;
use Object::Pad;

role Iterator {
    method next;
    method has_next;
}

1;
