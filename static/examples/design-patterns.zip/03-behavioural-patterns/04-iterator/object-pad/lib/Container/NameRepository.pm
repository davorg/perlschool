use v5.42;
use Object::Pad;

class Container::NameRepository :does(Container) {
    use Iterator::Name;

    field $names :param :reader;
    field $_iterator;

    method getIterator {
        $_iterator //= Iterator::Name->new(names => $self->names);
        return $_iterator;
    }
}

1;
