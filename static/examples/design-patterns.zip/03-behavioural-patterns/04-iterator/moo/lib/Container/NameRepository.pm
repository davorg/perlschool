package Container::NameRepository;

use Moo;
with qw/Container/;

use Iterator::Name;

has 'names'    => (is => 'ro', required => 1);
has 'iterator' => (
    is       => 'ro',
    lazy     => 1,
    init_arg => undef,
    default  => sub { Iterator::Name->new({ names => shift->names }) }
);

sub getIterator { Iterator::Name->new(names => shift->names) }

1;
