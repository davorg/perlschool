package Caretaker;

use Class;

sub BUILD { shift->{history} = [] }

sub add_memento {
    my ($self, $memento) = @_;

    push @{$self->{history}}, $memento;
}

sub get_memento { pop @{shift->{history}} }

1;
