use v5.42;
use experimental qw/class/;

class Memento {
    field $state :param :reader;
}

1;
