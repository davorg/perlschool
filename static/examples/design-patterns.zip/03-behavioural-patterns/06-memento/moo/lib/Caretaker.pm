package Caretaker;

use Moo;

has history => (is => 'rw', default => sub {[]});

sub add_memento {
    my ($self, $memento) = @_;

    push @{$self->history}, $memento;
}

sub get_memento {
    my ($self) = @_;

    pop @{$self->history};
}

1;
