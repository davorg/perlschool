package Observer::BinaryObserver;

use Moo;
with qw/Observer/;

sub update { sprintf("Binary string: %b.", shift->subject->state) }

1;
