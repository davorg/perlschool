package Observer::OctalObserver;

use Moo;
with qw/Observer/;

sub update { sprintf("Octal string: %o.", shift->subject->state) }

1;
