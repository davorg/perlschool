package Observer;

use Moo::Role;
requires qw/update/;

has 'subject' => (is => 'rw', required => 1);

1;
