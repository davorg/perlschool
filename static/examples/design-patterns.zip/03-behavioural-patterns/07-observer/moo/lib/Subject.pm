package Subject;

use Moo;
use Scalar::Util qw/weaken/;

has 'state'     => (is => 'rw');
has 'observers' => (is => 'rw', default => sub {[]});

sub setState {
    my ($self, $new_state) = @_;

    $self->state($new_state);
    return $self->notifyObservers;
}

sub attach {
    my ($self, $observer) = @_;

    push @{$self->observers}, $observer;
    weaken($self->observers->[-1]);
}

sub detach {
    my ($self, $observer) = @_;

    my $obs = $self->observers;
    for my $i (0 .. $#$obs) {
        if ($obs->[$i] == $observer) {
            splice @$obs, $i, 1;
            last;
        }
    }
}

sub notifyObservers {
    my ($self) = @_;

    my $res = [];
    foreach my $obs (@{$self->observers}) {
        push @$res, $obs->update;
    }
    return $res;
}

sub clear_observers { shift->observers([]) }

1;
