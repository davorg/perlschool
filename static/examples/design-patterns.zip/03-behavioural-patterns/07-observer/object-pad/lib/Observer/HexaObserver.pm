use Object::Pad;

class Observer::HexaObserver :does(Observer) {
    method update { sprintf("Hexa string: %x.", $self->subject->state) }
}

1;
