use Object::Pad;

class Observer::BinaryObserver :does(Observer) {
    method update { sprintf("Binary string: %b.", $self->subject->state) }
}

1;
