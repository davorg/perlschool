use Object::Pad;

class Subject {
    use Scalar::Util qw/weaken/;

    field $state     :accessor;
    field $observers :accessor = [];

    method setState($new_state) {
        $self->state($new_state);
        return $self->notifyObservers;
    }

    method attach($observer) {
        push @{$self->observers}, $observer;
        weaken($self->observers->[-1]);
    }

    method detach($observer) {
        my $obs = $self->observers;
        for my $i (0 .. $#$obs) {
            if ($obs->[$i] == $observer) {
                splice @$obs, $i, 1;
                last;
            }
        }
    }

    method notifyObservers {
        my $res = [];
        foreach my $obs (@{$self->observers}) {
            push @$res, $obs->update;
        }
        return $res;
    }

    method clear_observers { $self->observers([]) }
}

1;
