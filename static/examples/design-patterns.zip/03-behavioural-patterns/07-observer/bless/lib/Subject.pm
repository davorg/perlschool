package Subject;

use Class;
use Scalar::Util qw/weaken/;

sub BUILD {
    my ($self) = @_;

    $self->{state}     = undef;
    $self->{observers} = [];
}

sub state {
    my ($self, $state) = @_;

    $self->{state} = $state if defined $state;
    return $self->{state};
}

sub observers       { shift->{observers}      }
sub clear_observers { shift->{observers} = [] }

sub setState {
    my ($self, $new_state) = @_;

    $self->state($new_state);
    $self->notifyObservers;
}

sub attach {
    my ($self, $observer) = @_;

    push @{$self->observers}, $observer;
    weaken($self->observers->[-1]);
}

sub detach {
    my ($self, $observer) = @_;

    my $observers = $self->observers;
    foreach my $index (0 .. $#$observers) {
        if ($observers->[$index] == $observer) {
            splice @$observers, $index, 1;
            last;
        }
    }
    $self->{observers} = $observers;
}

sub notifyObservers {
    my $observers = shift->observers;
    [ map { $_->update } @$observers ];
}

1;
