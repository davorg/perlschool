package Observer::OctalObserver;

use Class;
with qw/Observer/;

sub BUILD {
    my ($self, $args) = @_;

    die "Missing key 'subject'." unless exists $args->{subject};
}

sub update { sprintf("Octal string: %o.", shift->subject->state) }

1;
