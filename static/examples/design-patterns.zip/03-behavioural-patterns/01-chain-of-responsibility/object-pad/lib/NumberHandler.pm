use Object::Pad;

class NumberHandler :does(Handler) {
    method handle($request) {
        return "NumberHandler processed request: $request" if ($request =~ /^\d+$/);
        return $self->pass_to_next($request);
    }
}

1;
