package NumberHandler;

use Moo;
with qw/Handler/;

sub handle {
    my ($self, $request) = @_;

    return "NumberHandler processed request: $request"
        if ($request =~ /^\d+$/);
    return $self->pass_to_next($request);
}

1;
