package Handler;

use Moo::Role;
requires qw/handle/;

has next => (is => 'rw');

sub pass_to_next {
    my ($self, $request) = @_;

    return $self->next->handle($request) if $self->next;
    return "No handler could process request: $request";
}

1;
