use Object::Pad;

role Game {
    method initialise;
    method startPlay;
    method endPlay;

    method play {
        $self->initialise;
        $self->startPlay;
        $self->endPlay;
    }
}

1;
