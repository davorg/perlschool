use Object::Pad;

class Game::Cricket :does(Game) {
    method initialise { print 'Cricket: initialise.'; }
    method startPlay  { print 'Cricket: start play.'; }
    method endPlay    { print 'Cricket: end play.';   }
}

1;
