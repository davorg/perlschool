package Game::Cricket;

use Moo;
with qw/Game/;

sub initialise { print 'Cricket: initialise.'; }
sub startPlay  { print 'Cricket: start play.'; }
sub endPlay    { print 'Cricket: end play.';   }

1;
