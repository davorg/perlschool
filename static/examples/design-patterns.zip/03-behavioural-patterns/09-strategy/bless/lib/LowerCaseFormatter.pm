package LowerCaseFormatter;

use Class;
with qw/FormatterStrategy/;

sub format { lc $_[1] }

1;
