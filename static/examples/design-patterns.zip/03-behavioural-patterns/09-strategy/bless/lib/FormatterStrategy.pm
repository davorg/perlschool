package FormatterStrategy;

use Role;
requires qw/format/;

1;
