use Object::Pad;

class TextFormatter {
    field $strategy :param;

    method strategy($new_strategy) {
        $strategy = $new_strategy if defined $new_strategy;
        return $strategy;
    }

    method publish($text) { $strategy->format($text) }
}

1;
