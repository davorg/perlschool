use Object::Pad;

class LowerCaseFormatter :does(FormatterStrategy) {
    method format { lc $_[1] }
}

1;
