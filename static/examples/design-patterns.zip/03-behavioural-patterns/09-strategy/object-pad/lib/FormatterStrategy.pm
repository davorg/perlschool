use Object::Pad;

role FormatterStrategy {
    method format;
}

1;
