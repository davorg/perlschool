package TextFormatter;

use Moo;
has strategy => (is => 'rw', required => 1);

sub publish($self, $text) { $self->strategy->format($text) }

1;
