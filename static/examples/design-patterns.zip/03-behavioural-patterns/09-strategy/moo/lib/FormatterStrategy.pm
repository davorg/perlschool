package FormatterStrategy;

use Moo::Role;
requires qw/format/;

1;
