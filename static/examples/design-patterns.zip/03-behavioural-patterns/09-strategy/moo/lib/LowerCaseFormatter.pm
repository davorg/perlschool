package LowerCaseFormatter;

use Moo;
with qw/FormatterStrategy/;

sub format { lc $_[1] }

1;
