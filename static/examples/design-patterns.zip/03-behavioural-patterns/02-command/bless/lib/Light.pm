package Light;

use Class;

sub BUILD {
    my ($self, $args) = @_;

    $self->{is_on} = undef;
}

sub is_on    { shift->{is_on}                }
sub turn_on  { shift->{is_on} = 1; 'ON'      }
sub turn_off { shift->{is_on} = 0; 'OFF'     }
sub status   { shift->{is_on} ? 'ON' : 'OFF' }

1;
