package RemoteControl;

use Class;

sub BUILD {
    my ($self) = @_;

    $self->{command} = undef;
    $self->{history} = [];
}
sub command     { shift->{command} }
sub history     { shift->{history} }
sub set_command { $_[0]->{command} = $_[1] }

sub press_button {
    my ($self) = @_;

    if ($self->command) {
        $self->command->execute;
        push @{$self->{history}}, $self->command;
    }
}

sub undo {
    my ($self) = @_;

    my $history = $self->history;
    if (@$history) {
        my $last_command = pop @$history;
        $last_command->unexecute;
    }
}

1;
