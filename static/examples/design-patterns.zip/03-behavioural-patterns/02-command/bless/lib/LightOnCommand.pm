package LightOnCommand;

use Class;
with qw/Command/;

sub execute   { shift->light->turn_on  }
sub unexecute { shift->light->turn_off }

1;
