package RemoteControl;

use Moo;

has command => (is => 'rw');
has history => (is => 'rw', default => sub {[]});

sub set_command { $_[0]->{command} = $_[1] }

sub press_button {
    my ($self) = @_;

    if ($self->command) {
        $self->command->execute;
        push @{$self->history}, $self->command;
    }
}

sub undo {
    my ($self) = @_;

    if (@{$self->history}) {
        my $last_command = pop @{$self->history};
        $last_command->unexecute;
    }
}

1;
