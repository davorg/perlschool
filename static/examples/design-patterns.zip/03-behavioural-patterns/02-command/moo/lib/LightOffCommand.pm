package LightOffCommand;

use Moo;
with qw/Command/;

sub execute   { shift->light->turn_off }
sub unexecute { shift->light->turn_on  }

1;
