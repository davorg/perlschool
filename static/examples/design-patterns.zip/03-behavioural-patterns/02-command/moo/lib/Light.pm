package Light;

use Moo;

has is_on => (is => 'rw', default => sub { 0 });

sub turn_on  { shift->is_on(1); 'ON'       }
sub turn_off { shift->is_on(0); 'OFF'      }
sub status   { shift->is_on ? 'ON' : 'OFF' }

1;
