use Object::Pad;

role Command {
    field $light :param :accessor;

    method execute;
    method unexecute;
}

1;
