use Object::Pad;

class Number :does(Expression) {
    field $value :param;

    method interpret { $value }
}

1;
