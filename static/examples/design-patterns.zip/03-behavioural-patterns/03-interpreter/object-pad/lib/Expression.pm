use Object::Pad;

role Expression {
    method interpret;
}

1;
