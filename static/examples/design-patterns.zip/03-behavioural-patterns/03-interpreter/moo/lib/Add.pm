package Add;

use Moo;
with qw/Expression/;

has left  => (is => 'ro', required => 1);
has right => (is => 'ro', required => 1);

sub interpret {
    my ($self) = @_;

    $self->left->interpret + $self->right->interpret
}

1;
