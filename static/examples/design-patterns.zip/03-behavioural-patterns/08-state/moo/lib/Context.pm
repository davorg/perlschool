package Context;

use Moo;

has 'state' => (
    is  => 'rw',
    isa => sub { die 'Invalid state.' unless $_[0]->does('State') }
);

1;
