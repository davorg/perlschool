package Criteria;

use Moo::Role;
requires qw/meetCriteria/;


1;
