package Criteria::Or;

use Moo;
with qw/Criteria/;

has 'criteria'      => (is => 'rw');
has 'otherCriteria' => (is => 'rw');

sub meetCriteria {
    my ($self, $persons) = @_;

    my $firstCriteria = $self->criteria->meetCriteria($persons);
    my $otherCriteria = $self->otherCriteria->meetCriteria($persons);

    map {
        if (!exists $firstCriteria->{$_}) {
            $firstCriteria->{$_} = $otherCriteria->{$_};
        }
    } keys %$otherCriteria;

    return $firstCriteria;
}

1;
