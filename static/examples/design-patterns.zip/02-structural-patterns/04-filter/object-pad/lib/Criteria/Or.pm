use Object::Pad;

class Criteria::Or :does(Criteria) {
    field $criteria      :param :reader :writer;
    field $otherCriteria :param :reader :writer;

    method meetCriteria ($persons) {
        my $firstCriteria = $criteria->meetCriteria($persons);
        my $otherCriteria = $otherCriteria->meetCriteria($persons);

        map {
            if (!exists $firstCriteria->{$_}) {
                $firstCriteria->{$_} = $otherCriteria->{$_};
            }
        } keys %$otherCriteria;

        return $firstCriteria;
    }
}

1;
