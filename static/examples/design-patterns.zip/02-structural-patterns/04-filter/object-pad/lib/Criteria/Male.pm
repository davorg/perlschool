use Object::Pad;

class Criteria::Male :does(Criteria) {
    method meetCriteria ($persons) {
        +{ map { $_->name => $_ } grep { uc($_->gender) eq 'M' } @$persons };
    }
}

1;
