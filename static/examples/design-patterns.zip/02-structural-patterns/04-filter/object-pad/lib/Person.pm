use Object::Pad;

class Person {
    field $name   :param :reader;
    field $gender :param :reader;
    field $status :param :reader;
}

1;
