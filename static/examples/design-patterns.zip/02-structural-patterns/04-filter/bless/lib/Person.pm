package Person;

use Class;

sub BUILD {
    my ($self, $args) = @_;

    foreach (qw/name gender status/) {
        die "Missing param $_\n" unless exists $args->{$_};
    }
}

sub name   { shift->{name}   }
sub gender { shift->{gender} }
sub status { shift->{status} }

1;
