package Criteria::Female;

use Class;
with qw/Criteria/;

sub meetCriteria {
    my ($self, $persons) = @_;

    +{ map { $_->name => $_ } grep { uc($_->gender) eq 'F' } @$persons };
}

1;
