package Employee;

use Class;

use overload q{""} => 'as_string', fallback => 1;

sub BUILD        { shift->{subordinates} = [] }
sub name         { shift->{name}              }
sub dept         { shift->{dept}              }
sub salary       { shift->{salary}            }
sub subordinates { shift->{subordinates}      }

sub add {
    my ($self, $employee) = @_;

    push @{$self->{subordinates}}, $employee;
}

sub as_string {
    my ($self, @args) = @_;

    sprintf("Employee: [Name: %s, Dept: %s, Salary: %d]",
        $self->name, $self->dept, $self->salary);
}

1;
