use v5.42;
use experimental 'class';

class Employee {
    use overload q{""} => 'as_string', fallback => 1;

    field $name         :reader :param;
    field $dept         :reader :param;
    field $salary       :reader :param;
    field $subordinates :reader = [];

    method add($employee) { push @$subordinates, $employee }

    method as_string {
        sprintf("Employee: [Name: %s, Dept: %s, Salary: %d]",
            $name, $dept, $salary);
    }
}

1;
