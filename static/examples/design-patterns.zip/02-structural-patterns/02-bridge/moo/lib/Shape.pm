package Shape;

use Moo::Role;
requires qw/draw/;
has 'drawAPI' => (is => 'ro', required => 1);

1;
