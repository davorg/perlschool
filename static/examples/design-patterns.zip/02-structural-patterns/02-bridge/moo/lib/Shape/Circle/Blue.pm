package Shape::Circle::Blue;

use Moo;
with qw/DrawAPI/;

sub drawCircle {
    my ($self, $radius, $x, $y) = @_;

    sprintf("drawCircle(color = blue; radius = %d; x = %d; y = %d)",
        $radius, $x, $y);
}

1;
