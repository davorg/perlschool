use Object::Pad;

role Shape {
    field $drawAPI :accessor :param;
    method draw;
}

1;
