use v5.42;
use Object::Pad;

class Shape::Circle::Blue :does(DrawAPI) {
    method drawCircle($radius, $x, $y) {
        sprintf("drawCircle(color = blue; radius = %d; x = %d; y = %d)",
            $radius, $x, $y);
    }
}

1;
