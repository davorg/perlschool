package Shape::Circle::Green;

use Class;
with qw/DrawAPI/;

sub drawCircle {
    my ($self, $radius, $x, $y) = @_;

    sprintf("drawCircle(color = green; radius = %d; x = %d; y = %d)",
        $radius, $x, $y);
}

1;
