package Shape::Circle;

use Class;
with qw/Shape/;

sub BUILD {
    my ($self, $args) = @_;

    foreach (qw/x y radius/) {
        die "Missing required key '$_'.\n"
            unless (exists $self->{$_});
    }
}

sub x      { shift->{x}      }
sub y      { shift->{y}      }
sub radius { shift->{radius} }

sub draw {
    my ($self) = @_;

    $self->drawAPI->drawCircle($self->radius, $self->x, $self->y);
}

1;
