package DrawAPI;

use Role;
requires qw/drawCircle/;

1;
