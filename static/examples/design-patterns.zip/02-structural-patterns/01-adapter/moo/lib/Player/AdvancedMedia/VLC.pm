package Player::AdvancedMedia::VLC;

use Moo;
with qw/Player::AdvancedMedia/;

sub playVLC { 'Playing VLC.' }
sub playMP4 {                }

1;
