package Player::AdvancedMedia::MP4;

use Moo;
with qw/Player::AdvancedMedia/;

sub playVLC {                }
sub playMP4 { 'Playing MP4.' }

1;
