use Object::Pad;

class Player::Media::Audio :does(Player::Media) {
    use Player::Media::Adapter;

    field $audio_type :param :accessor;
    field $audio      :accessor;

    ADJUST {
        if ($audio_type =~ /VLC|MP4/i) {
            $self->audio(Player::Media::Adapter->new(audio_type => $audio_type));
        }
    }

    method play {
        if ($audio_type =~ /VLC|MP4/i) {
            return $audio->play;
        }
        elsif ($audio_type =~ /MP3/i) {
            return 'Playing MP3.';
        }
    }
}

1;
