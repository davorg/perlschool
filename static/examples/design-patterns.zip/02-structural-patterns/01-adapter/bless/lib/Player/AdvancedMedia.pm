package Player::AdvancedMedia;

use Role;
requires qw/playVLC playMP4/;

1;
