package Player::AdvancedMedia::VLC;

use Class;
with qw/Player::AdvancedMedia/;

sub playVLC { 'Playing VLC.' }
sub playMP4 {                }

1;
