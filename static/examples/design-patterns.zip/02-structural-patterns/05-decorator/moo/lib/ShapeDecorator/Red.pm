package ShapeDecorator::Red;

use Moo;
extends qw/ShapeDecorator/;

sub draw {
    my ($self) = @_;

    $self->SUPER::draw . $self->redBorder;
}

sub redBorder { ' with a red border' }

1;
