package ShapeDecorator::Filled;

use Moo;
extends qw/ShapeDecorator/;

sub draw {
    my ($self) = @_;

    $self->SUPER::draw . $self->fill;
}

sub fill { ' filled' }

1;
