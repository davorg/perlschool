package Shape::Circle;

use Moo;
with qw/Shape/;

sub draw { 'A circle' }

1;
