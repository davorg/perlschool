package ShapeDecorator;

use Moo;
with qw/Shape/;

has 'shape'  => (
    is       => 'ro',
    isa      => sub { die 'Invalid shape.' unless $_[0]->DOES('Shape') },
    required => 1,
);

sub draw { shift->shape->draw }

1;
