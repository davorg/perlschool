package ShapeDecorator;

use Class;
with qw/Shape/;

sub BUILD {
    my ($self, $args) = @_;
    die "Missing required key 'shape'.\n" unless (exists $self->{shape});
    die 'Invalid shape' unless $self->{shape}->DOES('Shape')
}

sub draw  { shift->{shape}->draw }

1;
