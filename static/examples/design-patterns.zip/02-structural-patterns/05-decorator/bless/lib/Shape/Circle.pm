package Shape::Circle;

use Class;
with qw/Shape/;

sub draw { 'A circle' }

1;
