package ShapeDecorator::Filled;

use Class;
extends qw/ShapeDecorator/;

sub draw {
    my ($self) = @_;

    $self->SUPER::draw . $self->fill;
}

sub fill { ' filled' }

1;
