use Object::Pad;

class ShapeDecorator::Filled :isa(ShapeDecorator) {
    method draw { $self->SUPER::draw . $self->fill }
    method fill { ' filled'                        }
}

1;
