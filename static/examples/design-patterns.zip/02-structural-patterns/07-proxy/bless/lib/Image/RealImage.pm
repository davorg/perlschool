package Image::RealImage;

use Class;
with qw/Image/;

sub BUILD {
    my ($self, $args) = @_;

    die "filename is required" unless exists $args->{filename};
    $self->_build;
}

sub display { print sprintf('Displaying %s ...', $_[0]->{filename}) }
sub _build  { print sprintf('Loading %s ...', $_[0]->{filename})    }

1;
