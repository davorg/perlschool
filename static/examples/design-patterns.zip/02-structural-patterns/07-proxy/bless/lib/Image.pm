package Image;

use Role;
requires qw/display/;

1;
