package Image::ProxyImage;

use Moo;
with qw/Image/;
use Image::RealImage;

has 'image'    => (is => 'rw');
has 'filename' => (is => 'rw', required => 1);

sub display {
    my ($self) = @_;

    if (!defined $self->image) {
        $self->image(Image::RealImage->new({ filename => $self->filename }));
    }

    $self->image->display;
}

1;
