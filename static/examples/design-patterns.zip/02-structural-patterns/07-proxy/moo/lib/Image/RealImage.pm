package Image::RealImage;

use Moo;
with qw/Image/;

has 'filename' => (is =>'rw', required => 1);

sub BUILD {
    my ($self, @args) = @_;

    my $filename = $self->filename;
    print "Loading $filename ...";
}

sub display {
    my ($self) = @_;

    my $filename = $self->filename;
    print "Displaying $filename ...";
}

1;
