use Object::Pad;

class Image::RealImage :does(Image) {
    field $filename :param :reader;

    BUILD          { print "Loading $filename ..."    }
    method display { print "Displaying $filename ..." }
}

1;
