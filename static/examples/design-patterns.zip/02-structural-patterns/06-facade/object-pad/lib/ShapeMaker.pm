use Object::Pad;

use Shape::Circle;
use Shape::Square;
use Shape::Rectangle;

class ShapeMaker {
    field $circle    = Shape::Circle->new;
    field $square    = Shape::Square->new;
    field $rectangle = Shape::Rectangle->new;

    method drawCircle    { $circle->draw    }
    method drawSquare    { $square->draw    }
    method drawRectangle { $rectangle->draw }
}

1;
