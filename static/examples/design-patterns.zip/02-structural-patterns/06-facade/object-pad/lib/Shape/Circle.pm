use Object::Pad;

class Shape::Circle :does(Shape) {
    method draw { 'Inside Shape::Circle::draw()'    }
}

1;
